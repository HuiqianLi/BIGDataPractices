package com.qwk.dao;

import java.util.List;
import com.qwk.entity.*;

public interface BookDaoI {
	public List<Book> getAllBook();
}