package com.rhine.studySSM.service;

import com.rhine.studySSM.domain.Users;

public interface IUserService {
	Users userlogin(Users user);
}
