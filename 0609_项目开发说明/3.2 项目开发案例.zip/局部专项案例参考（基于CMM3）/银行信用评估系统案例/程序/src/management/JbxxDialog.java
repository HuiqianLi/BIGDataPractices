package management;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.event.*;
import java.sql.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class JbxxDialog extends JDialog {
  int myflag=1;
  String YHworkerID;
  String newGrade;
  JPanel panel1 = new JPanel();
  JComboBox jComboBox7 = new JComboBox();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JComboBox jComboBox3 = new JComboBox();
  JLabel jLabel17 = new JLabel();
  JTextField jTextField2 = new JTextField();
  JComboBox jComboBox12 = new JComboBox();
  JLabel jLabel6 = new JLabel();
  JComboBox jComboBox1 = new JComboBox();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel21 = new JLabel();
  JLabel jLabel26 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel20 = new JLabel();
  JComboBox jComboBox4 = new JComboBox();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JComboBox jComboBox14 = new JComboBox();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel24 = new JLabel();
  JComboBox jComboBox16 = new JComboBox();
  JComboBox jComboBox8 = new JComboBox();
  JComboBox jComboBox11 = new JComboBox();
  JComboBox jComboBox5 = new JComboBox();
  JLabel jLabel19 = new JLabel();
  JComboBox jComboBox10 = new JComboBox();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel28 = new JLabel();
  JLabel jLabel22 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JButton jButton1 = new JButton();
  JComboBox jComboBox2 = new JComboBox();
  JComboBox jComboBox9 = new JComboBox();
  JComboBox jComboBox13 = new JComboBox();
  JComboBox jComboBox17 = new JComboBox();
  JComboBox jComboBox18 = new JComboBox();
  String username;
  String usercard;
  String danBaoRenID;
  JButton jButton2 = new JButton();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  String newCardID="";

  public JbxxDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public JbxxDialog(Frame frame, String title, boolean modal,String str1,String str2) {
    super(frame, title, modal);
    username=str1;
    usercard=str2;
   try {
     jbInit();
     pack();
   }
   catch(Exception ex) {
     ex.printStackTrace();
   }
 }

     public JbxxDialog(String str1,String str2,String str4,String str5,String str3) {
       YHworkerID=str3;
       danBaoRenID=str4;
       newGrade=str5;
       username=str1;
       usercard=str2;
       try {
       jbInit();
       pack();
     }
     catch(Exception ex) {
       ex.printStackTrace();
     }


     }


     public JbxxDialog(String str1,String str2,String str3) {
  YHworkerID=str3;
  username=str1;
  usercard=str2;
  try {
  jbInit();
  pack();
}
catch(Exception ex) {
  ex.printStackTrace();
}


}

  public JbxxDialog(String str1,String str2,String str3,int  flagx) {
YHworkerID=str3;
username=str1;
usercard=str2;
    myflag=flagx;
try {
jbInit();
pack();
}
catch(Exception ex) {
ex.printStackTrace();
}


}






  public JbxxDialog() {
    this(null, "", false);
  }
  /*
  public JbxxDialog(String str1,String str2) {
    this(null, "", false,str1,str2);


 }
*/


  private void jbInit() throws Exception {

    this.setResizable(false);
    this.setTitle("�����ɹ��� ����д��ϸ�û�����");
    panel1.setLayout(null);
    jComboBox7.setBounds(new Rectangle(110, 149, 117, 20));
    jLabel16.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel16.setText("�ֵ�λ��������");
    jLabel16.setBounds(new Rectangle(5, 188, 112, 24));
    jLabel18.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel18.setText("��ͥ�˾�������");
    jLabel18.setBounds(new Rectangle(251, 183, 119, 23));
    jComboBox3.setBounds(new Rectangle(111, 93, 114, 18));
    jComboBox3.addActionListener(new JbxxDialog_jComboBox3_actionAdapter(this));
    jLabel17.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel17.setText("����������");
    jLabel17.setBounds(new Rectangle(250, 245, 98, 21));
    jTextField2.setText("");
    jTextField2.setBackground(Color.white);
    jTextField2.setEditable(false);
    jTextField2.setBounds(new Rectangle(111, 66, 112, 19));
    jComboBox12.setBounds(new Rectangle(366, 303, 122, 22));
    jLabel6.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel6.setText("����״��");
    jLabel6.setBounds(new Rectangle(7, 243, 84, 25));
    jComboBox1.setBounds(new Rectangle(111, 118, 116, 20));
    jTextField1.setText("");
    jTextField1.setBackground(Color.white);
    jTextField1.setEditable(false);
    jTextField1.setBounds(new Rectangle(111, 40, 112, 18));
    jLabel5.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel5.setText("ְҵ���");
    jLabel5.setBounds(new Rectangle(22, 94, 82, 14));
    jLabel8.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel8.setText("��������");
    jLabel8.setBounds(new Rectangle(252, 121, 78, 25));
    jLabel4.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel4.setText("�� ��");
    jLabel4.setBounds(new Rectangle(253, 68, 60, 18));
    jLabel21.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel21.setText("�ʻ�����");
    jLabel21.setBounds(new Rectangle(252, 299, 62, 24));
    jLabel26.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel26.setText("����¼");
    jLabel26.setBounds(new Rectangle(9, 300, 63, 24));
    jLabel12.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel12.setText("��λ����");
    jLabel12.setBounds(new Rectangle(22, 149, 66, 19));
    jLabel20.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel20.setText("�Ƿ���Ա��");
    jLabel20.setBounds(new Rectangle(4, 218, 101, 21));
    jComboBox4.setBounds(new Rectangle(111, 248, 116, 20));
    jLabel1.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel1.setForeground(Color.black);
    jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel1.setText("��  ��");
    jLabel1.setBounds(new Rectangle(17, 37, 49, 19));
    jLabel13.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel13.setText("ְ ��");
    jLabel13.setBounds(new Rectangle(253, 152, 62, 18));
    jLabel3.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel3.setForeground(Color.black);
    jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel3.setText("����֤");
    jLabel3.setBounds(new Rectangle(16, 64, 54, 16));
    jComboBox14.setBounds(new Rectangle(111, 275, 116, 21));
    jLabel2.setEnabled(true);
    jLabel2.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel2.setForeground(Color.black);
    jLabel2.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel2.setText("�� ��");
    jLabel2.setBounds(new Rectangle(246, 38, 48, 26));
    jLabel24.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel24.setText("ҵ���������");
    jLabel24.setBounds(new Rectangle(6, 274, 101, 18));
    jComboBox16.setBounds(new Rectangle(110, 307, 117, 21));
    jComboBox16.addActionListener(new JbxxDialog_jComboBox16_actionAdapter(this));
    jComboBox8.setBounds(new Rectangle(364, 150, 122, 19));
    jComboBox11.setBounds(new Rectangle(366, 273, 121, 20));
    jComboBox5.setBounds(new Rectangle(363, 122, 123, 20));
    jLabel19.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel19.setText("סլ����");
    jLabel19.setBounds(new Rectangle(251, 272, 80, 22));
    jComboBox10.setBounds(new Rectangle(367, 214, 120, 19));

    jLabel7.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel7.setText("�Ļ��̶�");
    jLabel7.setBounds(new Rectangle(20, 118, 78, 15));
    jLabel28.setBackground(new Color(217, 230, 236));
    jLabel28.setFont(new java.awt.Font("Dialog", 1, 22));
    jLabel28.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel28.setText("�� �� �� �� �� Ϣ");
    jLabel28.setBounds(new Rectangle(109, 0, 291, 35));
    jLabel22.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel22.setText("������(Ԫ)");
    jLabel22.setBounds(new Rectangle(254, 93, 92, 21));
    jLabel15.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel15.setText("��ͥ�˾���֧��");
    jLabel15.setBounds(new Rectangle(251, 213, 110, 21));
    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setBounds(new Rectangle(179, 340, 73, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 0, 13));
    jButton1.setText("�ύ");
    jButton1.addActionListener(new JbxxDialog_jButton1_actionAdapter(this));
    jComboBox2.setBounds(new Rectangle(361, 36, 122, 21));
    jComboBox9.setBounds(new Rectangle(111, 185, 116, 22));
    jComboBox13.setBounds(new Rectangle(366, 187, 121, 19));
    jComboBox17.setBounds(new Rectangle(366, 242, 121, 20));
    jComboBox18.setBounds(new Rectangle(111, 219, 116, 22));
    jButton2.setText("ȡ��");
    jButton2.addActionListener(new JbxxDialog_jButton2_actionAdapter(this));
    jButton2.setFont(new java.awt.Font("Dialog", 0, 13));
    jButton2.setBackground(new Color(151, 164, 203));
    jButton2.setBounds(new Rectangle(317, 339, 73, 25));
    jTextField3.setText("");
    jTextField3.setBounds(new Rectangle(361, 66, 122, 18));
    jTextField3.addActionListener(new JbxxDialog_jTextField3_actionAdapter(this));
    //jTextField4.addActionListener(new JbxxDialog_jTextField4_actionAdapter(this));
    jTextField4.setBounds(new Rectangle(362, 93, 122, 18));
    jTextField4.setBackground(Color.white);
    jTextField4.setEnabled(true);
    jTextField4.setEditable(false);
    jTextField4.setText("0");
    panel1.setBackground(new Color(212, 230, 236));
    getContentPane().add(panel1);
    panel1.add(jComboBox3, null);
    panel1.add(jComboBox1, null);
    panel1.add(jTextField1, null);
    panel1.add(jTextField2, null);
    panel1.add(jLabel28, null);
    panel1.add(jLabel18, null);
    panel1.add(jLabel15, null);
    panel1.add(jComboBox10, null);
    panel1.add(jComboBox11, null);
    panel1.add(jComboBox2, null);
    panel1.add(jComboBox7, null);
    panel1.add(jLabel16, null);
    panel1.add(jLabel20, null);
    panel1.add(jLabel24, null);
    panel1.add(jComboBox14, null);
    panel1.add(jComboBox13, null);
    panel1.add(jComboBox12, null);
    panel1.add(jComboBox18, null);
    panel1.add(jComboBox9, null);
    panel1.add(jLabel1, null);
    panel1.add(jLabel3, null);
    panel1.add(jLabel5, null);
    panel1.add(jLabel7, null);
    panel1.add(jLabel12, null);
    panel1.add(jLabel4, null);
    panel1.add(jLabel2, null);
    panel1.add(jLabel13, null);
    panel1.add(jComboBox8, null);
    panel1.add(jComboBox5, null);
    panel1.add(jComboBox17, null);
    panel1.add(jComboBox16, null);
    panel1.add(jButton1, null);
    panel1.add(jButton2, null);
    panel1.add(jLabel26, null);
    panel1.add(jTextField3, null);
    panel1.add(jLabel17, null);
    panel1.add(jLabel19, null);
    panel1.add(jLabel21, null);
    panel1.add(jTextField4, null);
    panel1.add(jLabel6, null);
    panel1.add(jComboBox4, null);
    panel1.add(jLabel8, null);
    panel1.add(jLabel22, null);

    jComboBox9.addItem("");
    jComboBox9.addItem("5������");
     jComboBox9.addItem("3-5��");
     jComboBox9.addItem("1-3��");
     jComboBox9.addItem("1������");

     jComboBox13.addItem("");
     jComboBox13.addItem("5000Ԫ����");
      jComboBox13.addItem("3000-5000Ԫ");
      jComboBox13.addItem("2000-3000Ԫ");
      jComboBox13.addItem("1000-2000Ԫ");
       jComboBox13.addItem("500-1000Ԫ");
        jComboBox13.addItem("500Ԫ����");

        jComboBox7.addItem("");
    jComboBox7.addItem("���ּ�����");
    jComboBox7.addItem("����");
    jComboBox7.addItem("�Ƽ�");
    jComboBox7.addItem("һ����ظɲ�");
    jComboBox7.addItem("��������Ա��");
    jComboBox7.addItem("�����ܾ���");
    jComboBox7.addItem("���ž���");
    jComboBox7.addItem("һ����ҵ�ɲ�");
    jComboBox7.addItem("������ҵԱ��");

    jComboBox3.addItem("");
    jComboBox3.addItem("����Ա");
    jComboBox3.addItem("��ʦ��ҽ����");
    jComboBox3.addItem("���ڡ���ʦ");
     jComboBox3.addItem("���ˡ�����");
    jComboBox3.addItem("��ҵ������˾ְԱ");
     jComboBox3.addItem("����ְҵ");


   jComboBox2.addItem("");
   jComboBox2.addItem("��");
   jComboBox2.addItem("Ů");
   jComboBox12.addItem("");

   jComboBox12.addItem("�����Լ����п�");
    jComboBox12.addItem("����");
    jComboBox12.addItem("���п�");
    jComboBox12.addItem("���������ڴ����ʻ�");
     jComboBox12.addItem("���ʻ�");

     jComboBox1.addItem("");
    jComboBox1.addItem("�о���������");
    jComboBox1.addItem("����");
    jComboBox1.addItem("��ר");
    jComboBox1.addItem("���У���ר");
    jComboBox1.addItem("����");

    jComboBox4.addItem("");
    jComboBox4.addItem("�ѻ�����Ů");
    jComboBox4.addItem("�ѻ�����Ů");
    jComboBox4.addItem("δ��");
    jComboBox4.addItem("����");

    jComboBox14.addItem("");
    jComboBox14.addItem("����");
    jComboBox14.addItem("һ��");
    jComboBox14.addItem("����");

    jComboBox16.addItem("");
    jComboBox16.addItem("�н���ѻ���");
    jComboBox16.addItem("�����ڼ�¼");
    jComboBox16.addItem("��δ���");
    jComboBox16.addItem("����������н��");
    jComboBox16.addItem("������������н��");

    jComboBox8.addItem("");
    jComboBox8.addItem("�߼�");
    jComboBox8.addItem("�м�");
    jComboBox8.addItem("����");
    jComboBox8.addItem("��");

    jComboBox11.addItem("");
    jComboBox11.addItem("����ס��");
    jComboBox11.addItem("�����");
    jComboBox11.addItem("���ù���");
    jComboBox11.addItem("����");

    jComboBox5.addItem("");
    jComboBox5.addItem("��ס����");
    jComboBox5.addItem("��ʱ����");

    jComboBox10.addItem("");
    jComboBox10.addItem("500Ԫ����");
    jComboBox10.addItem("500-1000Ԫ");
    jComboBox10.addItem("1000-3000Ԫ");
    jComboBox10.addItem("3000Ԫ����");

    jComboBox17.addItem("");
    jComboBox17.addItem("10000Ԫ����");
    jComboBox17.addItem("8000-10000Ԫ");
    jComboBox17.addItem("5000-8000Ԫ");
    jComboBox17.addItem("4000-5000Ԫ ");
    jComboBox17.addItem("3000-4000Ԫ");
    jComboBox17.addItem("2000-3000Ԫ");
    jComboBox17.addItem("1000-2000Ԫ");
    jComboBox17.addItem("1000Ԫ����");

    jComboBox18.addItem("");
    jComboBox18.addItem("��");
    jComboBox18.addItem("��");

    jTextField1.setText(username);
    jTextField2.setText(usercard);
  }

  void jComboBox16_actionPerformed(ActionEvent e) {

  }

  void jButton2_actionPerformed(ActionEvent e) {
        this.dispose();
  }

  void jComboBox3_actionPerformed(ActionEvent e) {

  }

  void jButton1_actionPerformed(ActionEvent e) {

    Connection con;
    String query;
    String query2;
    ResultSet rs;
    ResultSet rs2;
    PreparedStatement pstmt;
    PreparedStatement pstmt2;
    try{
    Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
    String url =
        "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";

    String username = "sa";
    String password = "";
    con = DriverManager.getConnection(url, username, password);
    int intYHworkerID=Integer.parseInt(YHworkerID);
   //String SQL = "Insert Into rejecttable(UserName,UserCard,Datet,Rejectexcuse) Values("+"\'"+Username+"\'"+ ","+"\'"+UserPID+"\'"+","+"\'"+sdf.format(today)+"\'"+","+"\'"+reason+"\'"+")";



  // String SQL = "Insert Into Users(UserName,UserCard,YHworkerID,UserSex) Values("+"\'"+jTextField1.getText() +"\'"+ ","+"\'"+jTextField2.getText() +"\'"+","+"\'"+intYHworkerID +"\'"+","+"\'"+(String)jComboBox2.getSelectedItem()+"\'"+")";


   if (
        (jTextField3.getText()).equals("")||
        (jTextField4.getText()).equals("")||
        ((String) jComboBox3.getSelectedItem()).equals("")||
        ((String) jComboBox1.getSelectedItem()).equals("")||
        ((String) jComboBox7.getSelectedItem()).equals("")||
        ((String) jComboBox9.getSelectedItem()).equals("")||
        ((String) jComboBox18.getSelectedItem()).equals("")||
        ((String) jComboBox4.getSelectedItem()).equals("")||
        ((String) jComboBox14.getSelectedItem()).equals("")||
        ((String) jComboBox16.getSelectedItem()).equals("")||
        ((String) jComboBox5.getSelectedItem()).equals("") ||
        ((String) jComboBox8.getSelectedItem()).equals("")||
        ((String) jComboBox13.getSelectedItem()).equals("")||
        ((String) jComboBox10.getSelectedItem()).equals("")||
        ((String) jComboBox17.getSelectedItem()).equals("")||
        ((String) jComboBox11.getSelectedItem()).equals("")||
        ((String) jComboBox12.getSelectedItem()).equals("")

        )
   {
        CheckDialog CheckDialog3=new CheckDialog("����ȷ��д�������ϣ�");
        CheckDialog3.setBounds(300,200,300,200);
        CheckDialog3.show();

   }
   else
   {
         String SQL = "Insert Into Users(UserName,UserCard,UserSex,UserAge,MarriageState,CultureState,RegistereState,IndividualIcome,AverageIcome,AverageExpend,HouseState,DbrUserId,YHworkerID)" +
         " Values(" + "\'" + jTextField1.getText() + "\'" + "," + "\'" +
         jTextField2.getText() + "\'" + "," + "\'"
         + (String) jComboBox2.getSelectedItem() + "\'" + "," + "\'" +
         Integer.parseInt(jTextField3.getText())
         + "\'" + "," + "\'" + (String) jComboBox4.getSelectedItem() + "\'" +
         "," + "\'" +
         (String) jComboBox1.getSelectedItem() + "\'" + "," + "\'" +
         (String) jComboBox5.getSelectedItem()
         + "\'" + "," + "\'" + (String) jComboBox17.getSelectedItem() + "\'" +
         "," + "\'" + (String) jComboBox13.getSelectedItem()
         + "\'" + "," + "\'" + (String) jComboBox10.getSelectedItem() + "\'" +
         "," + "\'" + (String) jComboBox11.getSelectedItem() + "\'" +
         "," + "\'" + danBaoRenID + "\'" +
         "," + "\'" + intYHworkerID + "\'" +
         ")";

     // String SQL = "Insert Into Users(UserName,UserCard,YHworkerID) Values('a','b','1000')";
     Statement stmt = con.createStatement();
     stmt.executeUpdate(SQL);

     this.dispose() ;

     String query3 = "select * from Users  ";
      pstmt = con.prepareStatement(query3);
      String newUID="";
      rs = pstmt.executeQuery();
      while(rs.next() ) {
       newUID=rs.getString("UserId");
}

if(myflag!=9)
{

     //д�����ÿ���
     String SQL2 = "Insert Into Creditcard(UserId,CreditcardGrade,CreditcardCode) Values("+"\'"+newUID+"\'"+ ","+"\'"+newGrade+"\'"+","+"\'"+"000000"+"\'"+")";
      Statement stmt2 = con.createStatement();
     stmt2.executeUpdate(SQL2);




     //д���ʺű�
     //�Ȼ�����ÿ���
     String query9 = "select * from Creditcard  ";
     pstmt = con.prepareStatement(query9);

     rs = pstmt.executeQuery();
     while(rs.next() ) {
       newCardID=rs.getString("CreditcardID");
     }
     int zero=Integer.parseInt(jTextField4.getText() );
     String SQL9 = "Insert Into Account(CreditcardId,AccountType,AccountDeposit) Values("+"\'"+Integer.parseInt(newCardID)+"\'"+","+"\'"+(String) jComboBox12.getSelectedItem()+"\'"+","+"\'"+zero+"\'"+ ")";
     Statement stmt9 = con.createStatement();
    stmt9.executeUpdate(SQL9);


    //д��ʹ�ü�¼��
    String SQL22 = "Insert Into UseRecord(CreditcardId,UseState) Values("+"\'"+Integer.parseInt(newCardID)+"\'"+","+"\'"+(String) jComboBox16.getSelectedItem()+"\'"+")";
     Statement stmt22 = con.createStatement();
    stmt22.executeUpdate(SQL22);


}//end of if



    //д��ʹ��ְҵ��
    String SQL23 = "Insert Into Profession(ProfessionTypes) Values("+"\'"+(String) jComboBox3.getSelectedItem()+"\'"+")";
     Statement stmt23 = con.createStatement();
    stmt23.executeUpdate(SQL23);





     //д�빤�������
     String query5 = "select * from Profession  ";  //����û�ְҵ������������д����һ����¼
      pstmt = con.prepareStatement(query5);
     String ProfessionId="";
      rs = pstmt.executeQuery();
     while(rs.next() ) {
         ProfessionId=rs.getString("ProfessionId");
}


     String SQL4 = "Insert Into WorkInstance(ProfessionId,UserId,WorkingState,WorkingPost,WorkingFirm) Values("
         +"\'"+Integer.parseInt(ProfessionId)+"\'"+","+"\'"+newUID+"\'"+","+"\'"+(String) jComboBox7.getSelectedItem()+"\'"+","+"\'"+(String) jComboBox8.getSelectedItem()+"\'"+","+"\'"+(String) jComboBox9.getSelectedItem()+"\'"+ ")";
     Statement stmt4 = con.createStatement();
     stmt4.executeUpdate(SQL4);

     if(myflag!=9)
{


     CheckDialog CheckDialogSuccess=new CheckDialog("�û��쿨�ɹ��� ","�û��ʺţ�         "+ newUID ,"�û����ÿ��ţ� "+ newCardID,"�û���ʼ����:    000000  ");
     CheckDialogSuccess.setBounds(300,200,300,200);
     CheckDialogSuccess.show();

}
   else
   {
     CheckDialog CheckDialogSuccess=new CheckDialog("�û��쿨�ɹ��� ","�û��ʺţ�         "+ newUID ," ","  ");
   CheckDialogSuccess.setBounds(300,200,300,200);
   CheckDialogSuccess.show();

   }






   }

    }
    catch(Exception eee)
    {
         eee.printStackTrace();
         CheckDialog CheckDialog3=new CheckDialog("��д��������ȷ��д����ѡ�");
         CheckDialog3.setBounds(300,200,300,200);
         CheckDialog3.show();


    }


  }

  void jTextField3_actionPerformed(ActionEvent e) {

  }


}

class JbxxDialog_jComboBox16_actionAdapter implements java.awt.event.ActionListener {
  JbxxDialog adaptee;

  JbxxDialog_jComboBox16_actionAdapter(JbxxDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jComboBox16_actionPerformed(e);
  }
}

class JbxxDialog_jButton2_actionAdapter implements java.awt.event.ActionListener {
  JbxxDialog adaptee;

  JbxxDialog_jButton2_actionAdapter(JbxxDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class JbxxDialog_jComboBox3_actionAdapter implements java.awt.event.ActionListener {
  JbxxDialog adaptee;

  JbxxDialog_jComboBox3_actionAdapter(JbxxDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jComboBox3_actionPerformed(e);
  }
}

class JbxxDialog_jButton1_actionAdapter implements java.awt.event.ActionListener {
  JbxxDialog adaptee;

  JbxxDialog_jButton1_actionAdapter(JbxxDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class JbxxDialog_jTextField3_actionAdapter implements java.awt.event.ActionListener {
  JbxxDialog adaptee;

  JbxxDialog_jTextField3_actionAdapter(JbxxDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jTextField3_actionPerformed(e);
  }
}





