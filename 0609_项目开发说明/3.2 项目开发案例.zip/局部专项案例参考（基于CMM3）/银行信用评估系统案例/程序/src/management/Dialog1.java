package management;

import javax.swing.*;
import java.awt.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class Dialog1 extends JFrame {
  JPanel jPanel1 = new JPanel();
  OverlayLayout2 overlayLayout21 = new OverlayLayout2();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JLabel jLabel1 = new JLabel();

  public Dialog1() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    this.getContentPane().setBackground(new Color(217, 230, 236));
    this.setLocale(new java.util.Locale("ar", "AE", ""));
    this.setResizable(false);
    this.setState(Frame.NORMAL);
    this.setTitle("ȷ��");
    this.getContentPane().setLayout(overlayLayout21);
    jPanel1.setBackground(new Color(217, 230, 236));
    jPanel1.setMaximumSize(new Dimension(32767, 32767));
    jPanel1.setLayout(null);
    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setBounds(new Rectangle(68, 73, 73, 37));
    jButton1.setFont(new java.awt.Font("Dialog", 0, 14));
    jButton1.setText("��");
    jButton1.addActionListener(new Dialog1_jButton1_actionAdapter(this));
    jButton2.setBackground(new Color(151, 164, 200));
    jButton2.setBounds(new Rectangle(232, 72, 75, 38));
    jButton2.setFont(new java.awt.Font("Dialog", 0, 14));
    jButton2.setToolTipText("");
    jButton2.setText("��");
    jButton2.addActionListener(new Dialog1_jButton2_actionAdapter(this));
    jLabel1.setFont(new java.awt.Font("Dialog", 0, 14));
    jLabel1.setText("�Ƿ�ȷ���˳���ѯϵͳ��");
    jLabel1.setBounds(new Rectangle(17, 13, 250, 44));
    this.getContentPane().add(jPanel1, null);
    this.setSize(new Dimension(422, 136));
    this.setLocation(400,500);
    this.toFront();
    jPanel1.add(jLabel1, null);
    jPanel1.add(jButton1, null);
    jPanel1.add(jButton2, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {
        System.exit(0);
  }

  void jButton2_actionPerformed(ActionEvent e) {
       this.dispose();
  }
}

class Dialog1_jButton1_actionAdapter implements java.awt.event.ActionListener {
  Dialog1 adaptee;

  Dialog1_jButton1_actionAdapter(Dialog1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class Dialog1_jButton2_actionAdapter implements java.awt.event.ActionListener {
  Dialog1 adaptee;

  Dialog1_jButton2_actionAdapter(Dialog1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}
