package management;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.sql.*;
import com.borland.dx.dataset.*;
import com.borland.dx.sql.dataset.*;
import com.borland.dbswing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class basicInf extends JPanel {
  PreparedStatement pstmt2;
 String query2;
 Connection con;
 ResultSet rs;
 String CreditcardId;
  BorderLayout borderLayout1 = new BorderLayout();
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JTextArea jTextArea2 = new JTextArea();
  JTextArea jTextArea1 = new JTextArea();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  GridBagLayout gridBagLayout2 = new GridBagLayout();

  public basicInf() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public basicInf(String strx1) {
     CreditcardId = strx1;
     try {
       jbInit();
     }
     catch (Exception e) {
       e.printStackTrace();
     }
   }


  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    jPanel1.setBackground(new Color(217, 230, 236));
    jPanel1.setFont(new java.awt.Font("Dialog", 0, 12));
    jPanel1.setAlignmentX((float) 0.5);
    jPanel1.setLayout(gridBagLayout1);
    jTabbedPane1.setBackground(new Color(217, 230, 236));
    jTabbedPane1.setFont(new java.awt.Font("Dialog", 0, 14));
    jTextArea2.setBackground(new Color(217, 230, 236));
  jTextArea2.setFont(new java.awt.Font("Dialog", 0, 14));
    jTextArea2.setAlignmentX((float) 0.5);
 jTextArea2.setTabSize(8);
 jTextArea1.setBackground(new Color(217, 230, 236));
 jTextArea1.setFont(new java.awt.Font("Dialog", 0, 14));
 jTextArea1.setText("");
 jTextArea1.setTabSize(8);
 jPanel2.setLayout(gridBagLayout2);
 jPanel2.setBackground(new Color(217, 230, 236));
    this.add(jTabbedPane1, BorderLayout.CENTER);
 jTabbedPane1.add(jPanel1,    "�û���Ϣ");
 jPanel1.add(jTextArea2,  new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(28, 47, 63, 72), 407, 305));
 jTabbedPane1.add(jPanel2,     "���ÿ���Ϣ");
 jPanel2.add(jTextArea1,  new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(37, 42, 37, 73), 411, 322));
    try {
    String url =
        "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
    String username = "sa";
    String password = "";
    con = DriverManager.getConnection(url, username, password);
    query2 =
     "SELECT * FROM Account where CreditcardId=?";
      pstmt2 = con.prepareStatement(query2);
      pstmt2.setString(1,CreditcardId);
      rs = pstmt2.executeQuery();
      if(rs.next())
      {
        jTextArea2.append("\n\n");
        jTextArea2.append("�ʻ����ͣ� " + rs.getString("AccountType") + "\n\n");
        jTextArea2.append("�ʻ��� " + rs.getString("AccountDeposit") + "\n\n");
      }

    query2 =
        "SELECT * FROM Creditcard where CreditcardId="+CreditcardId;
    pstmt2 = con.prepareStatement(query2);
    rs = pstmt2.executeQuery();
    if(rs.next()){
      if (rs.getString("CreditcardGrade").equalsIgnoreCase("A")) {
        jTextArea1.append("͸֧��ȣ�50000 \n\n");
      }
      else if (rs.getString("CreditcardGrade").equalsIgnoreCase("B")) {
        jTextArea1.append("͸֧��ȣ�40000 \n\n");
      }
      else if (rs.getString("CreditcardGrade").equalsIgnoreCase("C")) {
        jTextArea1.append("͸֧��ȣ�30000 \n\n");
      }
      else if (rs.getString("CreditcardGrade").equalsIgnoreCase("D")) {
        jTextArea1.append("͸֧��ȣ�20000 \n\n");
      }
      else if (rs.getString("CreditcardGrade").equalsIgnoreCase("E")) {
        jTextArea1.append("͸֧��ȣ�10000 \n\n");
      }
      else if (rs.getString("CreditcardGrade").equalsIgnoreCase("F")) {
        jTextArea1.append("͸֧��ȣ�5000 \n\n");
      }
      else if (rs.getString("CreditcardGrade").equalsIgnoreCase("G")) {
        jTextArea1.append("͸֧��ȣ�2000 \n\n");
      }
    }


    query2 =
          "SELECT * FROM Account where CreditcardId=?";
      pstmt2 = con.prepareStatement(query2);
      pstmt2.setString(1,CreditcardId);
      rs = pstmt2.executeQuery();
    while(rs.next())
    {
      jTextArea2.append("ʹ�ô����� " + rs.getString("UseNum") + "\n\n");
      jTextArea2.append("ʹ�ý� " + rs.getString("UseMoney") + "\n\n");
      jTextArea2.append("ʹ��ʱ�䣺 " + rs.getString("UseTime") + "\n\n");
      jTextArea2.append("ʹ��״̬�� " + rs.getString("UseState") + "\n\n");
    }
    query2 =
         "SELECT UserId FROM Creditcard where CreditcardId="+CreditcardId;
     pstmt2 = con.prepareStatement(query2);
     rs = pstmt2.executeQuery();
     if(rs.next())
     {
       query2 =
         "SELECT * FROM Users where UserId="+rs.getString("UserId");
       pstmt2 = con.prepareStatement(query2);
       rs = pstmt2.executeQuery();
       if(rs.next())
       {
         jTextArea1.append("");
         jTextArea1.append("�û����� " + rs.getString("UserName") + "\n\n");
         jTextArea1.append("�Ա� " + rs.getString("UserSex") + "\n\n");
         jTextArea1.append("���䣺 " + rs.getString("UserAge") + "\n\n");
         jTextArea1.append("����֤�ţ� " + rs.getString("UserCard") + "\n\n");
         jTextArea1.append("����״���� " + rs.getString("MarriageState") + "\n\n");
         jTextArea1.append("�Ļ��̶ȣ� " + rs.getString("CultureState") + "\n\n");
         jTextArea1.append("�������ʣ� " + rs.getString("RegistereState") + "\n\n");
         jTextArea1.append("���������룺 " + rs.getString("IndividualIcome") + "\n\n");
         jTextArea1.append("��ͥ�˾������룺 " + rs.getString("AverageIcome") + "\n\n");
         jTextArea1.append("��ͥ�˾��¹̶�֧���� " + rs.getString("AverageExpend") + "\n\n");
       }
     }
  }
  catch (Exception ep) {
    System.out.print("ϵͳ�������������С�");
  }
  }
}
