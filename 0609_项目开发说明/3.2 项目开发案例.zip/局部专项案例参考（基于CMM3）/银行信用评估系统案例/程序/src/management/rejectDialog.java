package management;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.text.SimpleDateFormat;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class rejectDialog extends JDialog {
  JPanel panel1 = new JPanel();
  TextArea textArea1 = new TextArea();
  JLabel jLabel4 = new JLabel();
  JButton jButton2 = new JButton();
  JButton jButton1 = new JButton();
  JLabel jLabel1 = new JLabel();
  JTextField jTextField1 = new JTextField();
  String str1;
  String username;
  String usercard;
  Statement stmt;
  Connection con;
  String query;
  ResultSet rs;
  MessageDialog  MessageDialog1;
  java.util.Date today=new java.util.Date();
   SimpleDateFormat sdf=new  SimpleDateFormat("yyyy��MM��dd��hhʱmm��ss�� ");

  public rejectDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public rejectDialog() {
    this(null, "", false);
  }
  public rejectDialog(String str1,String str2) {
    this(null, "", false);
    username=str1;
    usercard=str2;
}


  private void jbInit() throws Exception {
    panel1.setLayout(null);
    textArea1.setText("");
    textArea1.setBounds(new Rectangle(11, 45, 314, 153));
    jLabel4.setBounds(new Rectangle(9, 1, 231, 34));
    jLabel4.setText("�����벵�����ɣ�");
    jLabel4.setFont(new java.awt.Font("����", 1, 25));
    jButton2.setText("����");
    jButton2.addActionListener(new rejectDialog_jButton2_actionAdapter(this));
    jButton2.setBackground(new Color(151, 164, 203));
    jButton2.setBounds(new Rectangle(181, 253, 72, 25));
 //   jButton1.addActionListener(new rejectPanel_jButton1_actionAdapter(this));
    jButton1.setText("�ύ");
    jButton1.addActionListener(new rejectDialog_jButton1_actionAdapter(this));
    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setBounds(new Rectangle(67, 254, 73, 25));
    jLabel1.setBounds(new Rectangle(11, 214, 106, 25));
    jLabel1.setText("�ύ���ڣ�");
    jLabel1.setFont(new java.awt.Font("����", 1, 20));
    jTextField1.setBackground(Color.white);
    jTextField1.setEditable(false);
    jTextField1.setBounds(new Rectangle(123, 217, 202, 21));
    jTextField1.setText("");
    this.getContentPane().setBackground(new Color(217, 230, 236));
    this.setModal(true);
    this.setResizable(false);
    this.setTitle("�����ⵣ������");
    this.getContentPane().setLayout(null);
    panel1.setBackground(new Color(217, 230, 236));
    panel1.setBounds(new Rectangle(0, 10, 343, 290));
    getContentPane().add(panel1, null);
    panel1.add(textArea1, null);
    panel1.add(jLabel4, null);
    panel1.add(jLabel1, null);
    panel1.add(jTextField1, null);
    panel1.add(jButton2, null);
    panel1.add(jButton1, null);
    Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
   String url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
   String username= "sa";
   String password= "";
   con = DriverManager.getConnection(url,username,password);
   MessageDialog1=new  MessageDialog();
    jTextField1.setText(sdf.format(today));
  }

  void jButton2_actionPerformed(ActionEvent e) {
  this.dispose();
  }

  void jButton1_actionPerformed(ActionEvent e) {
    str1=textArea1.getText();
   try{
     query = "Insert Into rejecttable(UserName,UserCard,RejectDate,Rejectexcuse) Values("+"\'"+username+"\'"+","+"\'"+usercard+"\'"+","+"\'"+sdf.format(today)+"\'"+","+"\'"+str1+"\'"+")";
     stmt = con.createStatement();
     stmt.executeUpdate(query);
     MessageDialog1.setBounds(230,180,150,125);
     MessageDialog1.show();
     this.dispose();
   }
   catch(Exception eef)
   { System.out.print("ϵͳ�������������С�");
   }
  }
}

 class rejectDialog_jButton2_actionAdapter implements java.awt.event.ActionListener {
  rejectDialog adaptee;

  rejectDialog_jButton2_actionAdapter(rejectDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class rejectDialog_jButton1_actionAdapter implements java.awt.event.ActionListener {
  rejectDialog adaptee;

  rejectDialog_jButton1_actionAdapter(rejectDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}
