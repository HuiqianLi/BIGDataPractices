package management;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class messaDialog extends JDialog {
  JPanel panel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JButton jButton1 = new JButton();

  public messaDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public messaDialog() {
    this(null, "", false);
  }

  private void jbInit() throws Exception {
    panel1.setLayout(null);
    jLabel1.setFont(new java.awt.Font("�����п�", 0, 18));
    jLabel1.setText("û�в�����¼");
    jLabel1.setBounds(new Rectangle(14, 6, 123, 33));
    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setBounds(new Rectangle(28, 49, 73, 25));
    jButton1.setText("ȷ��");
    jButton1.addActionListener(new messDialog_jButton1_actionAdapter(this));
    this.setResizable(false);
    panel1.setBackground(new Color(217, 230, 236));
    getContentPane().add(panel1);
    panel1.add(jLabel1, null);
    panel1.add(jButton1, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    this.dispose();
  }
}

class messDialog_jButton1_actionAdapter implements java.awt.event.ActionListener {
  messaDialog adaptee;

  messDialog_jButton1_actionAdapter(messaDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}
