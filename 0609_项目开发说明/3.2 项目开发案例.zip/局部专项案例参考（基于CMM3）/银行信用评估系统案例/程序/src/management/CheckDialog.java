package management;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class CheckDialog extends JDialog {
  JPanel panel1 = new JPanel();
  JLabel jLabel2 = new JLabel();
  JButton jButton1 = new JButton();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();

  public CheckDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public CheckDialog() {
    this(null, "", false);
  }
  public CheckDialog(String a) {
      this(null, "", false);
      jLabel2.setText(a);
}

    public CheckDialog(String a,String b,String c,String d) {
        this(null, "", false);
        jLabel2.setText(a);
        jLabel1.setText(b);
        jLabel3.setText(c);
        jLabel4.setText(d);




  }



/*
    public CheckDialog(String a,int flag,JSplitPane jSplitPane1) {
        this(null, "", false);
        jLabel2.setText(a);
        if(flag==0)
           jSplitPane1.add(WarranteeEvaluate1,JSplitPane.RIGHT);
  }
*/


  private void jbInit() throws Exception {
    panel1.setLayout(null);
    jLabel2.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel2.setBounds(new Rectangle(21, 16, 262, 26));
    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setBounds(new Rectangle(114, 106, 90, 27));
    jButton1.setFont(new java.awt.Font("Dialog", 0, 15));
    jButton1.setText("ȷ  ��");
    jButton1.addKeyListener(new CheckDialog_jButton1_keyAdapter(this));
    jButton1.addActionListener(new CheckDialog_jButton1_actionAdapter(this));
    this.setForeground(Color.black);
    this.setTitle(" �� ��");
    jLabel1.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel1.setText("");
    jLabel1.setBounds(new Rectangle(19, 39, 361, 25));
    jLabel3.setBounds(new Rectangle(20, 58, 361, 25));
    jLabel3.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel3.setText("");
    jLabel4.setBounds(new Rectangle(20, 78, 361, 25));
    jLabel4.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel4.setOpaque(false);
    panel1.setBackground(new Color(217, 230, 236));
    getContentPane().add(panel1);
    panel1.add(jLabel1, null);
    panel1.add(jLabel2, null);
    panel1.add(jLabel3, null);
    panel1.add(jLabel4, null);
    panel1.add(jButton1, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {
     this.dispose();
  }

  void jButton1_keyPressed(KeyEvent e) {

  }
}

class CheckDialog_jButton1_actionAdapter implements java.awt.event.ActionListener {
  CheckDialog adaptee;

  CheckDialog_jButton1_actionAdapter(CheckDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class CheckDialog_jButton1_keyAdapter extends java.awt.event.KeyAdapter {
  CheckDialog adaptee;

  CheckDialog_jButton1_keyAdapter(CheckDialog adaptee) {
    this.adaptee = adaptee;
  }
  public void keyPressed(KeyEvent e) {
    adaptee.jButton1_keyPressed(e);
  }
}
