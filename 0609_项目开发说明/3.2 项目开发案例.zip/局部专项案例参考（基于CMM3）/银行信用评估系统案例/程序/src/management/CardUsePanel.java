package management;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import com.borland.dbswing.*;
import com.borland.dx.sql.dataset.*;
import com.borland.dx.dataset.*;
import java.sql.*;
import java.awt.event.*;
//import javax.swing.JOptionPane;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */
//
public class CardUsePanel extends JPanel {
  JLabel jLabel4 = new JLabel();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JLabel jLabel2 = new JLabel();
  JTextField jTextField5 = new JTextField();
  JPanel jPanel1 = new JPanel();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField1 = new JTextField();
  JTextField jTextField4 = new JTextField();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  TitledBorder titledBorder3;
  TitledBorder titledBorder4;
  TitledBorder titledBorder5;
  TitledBorder titledBorder6;
  TitledBorder titledBorder7;
  TitledBorder titledBorder8;
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JTextField jTextField6 = new JTextField();
  JLabel jLabel10 = new JLabel();
  JTextField jTextField7 = new JTextField();
  JPanel jPanel2 = new JPanel();
  JTextField jTextField8 = new JTextField();
  JLabel jLabel11 = new JLabel();
  JTextField jTextField9 = new JTextField();
  JTextField jTextField10 = new JTextField();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JTextField jTextField11 = new JTextField();
  JLabel jLabel16 = new JLabel();
  JTextField jTextField12 = new JTextField();
  JPanel jPanel3 = new JPanel();
  JTextField jTextField13 = new JTextField();
  JLabel jLabel17 = new JLabel();
  JTextField jTextField14 = new JTextField();
  JTextField jTextField15 = new JTextField();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JLabel jLabel110 = new JLabel();
  JLabel jLabel111 = new JLabel();
  JTextField jTextField16 = new JTextField();
  JLabel jLabel112 = new JLabel();
  JTextField jTextField20 = new JTextField();
  JPanel jPanel4 = new JPanel();
  JTextField jTextField18 = new JTextField();
  JLabel jLabel113 = new JLabel();
  JTextField jTextField19 = new JTextField();
  JTextField jTextField17 = new JTextField();
  JLabel jLabel114 = new JLabel();
  JLabel jLabel115 = new JLabel();
  JLabel jLabel116 = new JLabel();
  JLabel jLabel117 = new JLabel();
  JTextField jTextField23 = new JTextField();
  JLabel jLabel118 = new JLabel();
  JTextField jTextField25 = new JTextField();
  JPanel jPanel5 = new JPanel();
  JTextField jTextField22 = new JTextField();
  JLabel jLabel119 = new JLabel();
  JTextField jTextField21 = new JTextField();
  JTextField jTextField24 = new JTextField();
  JLabel jLabel1110 = new JLabel();
  PreparedStatement pstmt,pstmt2;
   Connection con;
   String query,query2;
   ResultSet rs;
   String Yjcky3, Yjcky3_15, Yjcky15_5, Yjcky5_1, Yjcky1, Yjljtz5, Yjljtz2_5;
   String Yjljtz1_2, Yjljtz1_1, Yjljtz1, Yhktzcs10, Yhktzcs6_9, Yhktzcs3_5;
   String Yhktzcs2, Yhktzcs0, Yjxfcs10, Yjxfcs6_9, Yjxfcs3_5, Yjxfcs2, Yjxfcs0;
   String Yjxf1, Yjxf5_1, Yjxf5_5, Yjxf5, Yjxf0;
  public CardUsePanel() {
    try {
      jbInit();
      connect();
      loaddata();
   }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    titledBorder4 = new TitledBorder("");
    titledBorder5 = new TitledBorder("");
    titledBorder6 = new TitledBorder("");
    titledBorder7 = new TitledBorder("");
    titledBorder8 = new TitledBorder("");
    titledBorder9 = new TitledBorder("");
    jLabel4.setBounds(new Rectangle(189, 8, 77, 16));
    jLabel4.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel4.setText("1500-500Ԫ");
    this.setLayout(gridBagLayout1);
    jLabel1.setFont(new java.awt.Font("Dialog", 0, 14));
    jLabel1.setText("�¾�������");
    jLabel3.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel3.setText("3000-1500Ԫ");
    jLabel3.setBounds(new Rectangle(98, 10, 81, 16));
    jTextField3.setText("jTextField3");
    jTextField3.setBounds(new Rectangle(187, 28, 57, 22));
    jLabel2.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel2.setText("3000Ԫ����");
    jLabel2.setBounds(new Rectangle(24, 7, 68, 16));
    //jButton1.addActionListener(new CardUsePanel_jButton1_actionAdapter(this));
    //jButton1.addActionListener(new BadBehaviorPanel_jButton1_actionAdapter(this));
    //jButton1.addActionListener(new CardUsePanel_jButton1_actionAdapter(this));
    jTextField5.setText("jTextField5");
    jTextField5.setBounds(new Rectangle(352, 30, 57, 22));
    jPanel1.setBackground(new Color(217, 230, 236));
    jPanel1.setBorder(titledBorder9);
    jPanel1.setLayout(null);
    jTextField2.setText("jTextField2");
    jTextField2.setBounds(new Rectangle(104, 27, 57, 22));
    jTextField1.setText("jTextField1");
    jTextField1.setBounds(new Rectangle(28, 28, 57, 22));
    jTextField4.setText("jTextField4");
    jTextField4.setBounds(new Rectangle(266, 28, 65, 22));
    jLabel5.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel5.setText("500-100Ԫ");
    jLabel5.setBounds(new Rectangle(266, 9, 62, 16));
    jLabel6.setText("100Ԫ����");
    jLabel6.setBounds(new Rectangle(349, 9, 62, 16));
    jLabel7.setBounds(new Rectangle(181, 11, 77, 16));
    jLabel7.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel7.setText("1000-2000Ԫ");
    jLabel8.setFont(new java.awt.Font("Dialog", 0, 14));
    jLabel8.setText("�¾��ۼ�͸֧��");
    jLabel9.setBounds(new Rectangle(100, 12, 76, 16));
    jLabel9.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel9.setText("2000-5000Ԫ");
    jTextField6.setBounds(new Rectangle(22, 32, 57, 22));
    jTextField6.setText("jTextField3");
    jLabel10.setBounds(new Rectangle(23, 12, 76, 16));
    jLabel10.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel10.setText("5000Ԫ����");
    jTextField7.setBounds(new Rectangle(104, 34, 57, 22));
    jTextField7.setText("jTextField5");
    jPanel2.setLayout(null);
    jPanel2.setBackground(new Color(217, 230, 236));
    jPanel2.setBorder(titledBorder2);
    jTextField8.setText("jTextField2");
    jTextField8.setBounds(new Rectangle(188, 32, 57, 22));
    jLabel11.setText("100Ԫ���� ");
    jLabel11.setBounds(new Rectangle(347, 9, 61, 16));
    jTextField9.setText("jTextField1");
    jTextField9.setBounds(new Rectangle(267, 32, 57, 22));
    jTextField10.setText("jTextField4");
    jTextField10.setBounds(new Rectangle(347, 29, 65, 22));
    jLabel12.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel12.setText("100-1000Ԫ");
    jLabel12.setBounds(new Rectangle(269, 11, 69, 16));
    jLabel13.setBounds(new Rectangle(197, 10, 77, 16));
    jLabel13.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel13.setText("3-5��");
    jLabel14.setFont(new java.awt.Font("Dialog", 0, 14));
    jLabel14.setText("�ѻ���͸֧����");
    jLabel15.setBounds(new Rectangle(118, 10, 54, 16));
    jLabel15.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel15.setText("6-9��");
    jTextField11.setBounds(new Rectangle(28, 26, 57, 22));
    jTextField11.setText("jTextField3");
    jLabel16.setBounds(new Rectangle(26, 9, 56, 16));
    jLabel16.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel16.setText("10������");
    jTextField12.setBounds(new Rectangle(108, 27, 57, 22));
    jTextField12.setText("jTextField5");
    jPanel3.setLayout(null);
    jPanel3.setBackground(new Color(217, 230, 236));
    jPanel3.setBorder(titledBorder2);
    jTextField13.setText("jTextField2");
    jTextField13.setBounds(new Rectangle(187, 27, 57, 22));
    jLabel17.setToolTipText("");
    jLabel17.setText("0��");
    jLabel17.setBounds(new Rectangle(366, 8, 34, 16));
    jTextField14.setText("jTextField1");
    jTextField14.setBounds(new Rectangle(265, 27, 57, 22));
    jTextField15.setText("jTextField4");
    jTextField15.setBounds(new Rectangle(346, 26, 65, 22));
    jLabel18.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel18.setRequestFocusEnabled(true);
    jLabel18.setText("2������");
    jLabel18.setBounds(new Rectangle(269, 8, 55, 16));
    jLabel19.setBounds(new Rectangle(196, 10, 77, 16));
    jLabel19.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel19.setText("3-5��");
    jLabel110.setFont(new java.awt.Font("Dialog", 0, 14));
    jLabel110.setText("�¾����Ѵ���");
    jLabel111.setBounds(new Rectangle(110, 9, 54, 16));
    jLabel111.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel111.setText("6-9��");
    jTextField16.setBounds(new Rectangle(23, 29, 57, 22));
    jTextField16.setText("jTextField3");
    jLabel112.setBounds(new Rectangle(25, 9, 56, 16));
    jLabel112.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel112.setText("10������");
    jTextField20.setBounds(new Rectangle(352, 30, 57, 22));
    jTextField20.setText("jTextField5");
    jPanel4.setLayout(null);
    jPanel4.setBackground(new Color(217, 230, 236));
    jPanel4.setBorder(titledBorder2);
    jTextField18.setText("jTextField2");
    jTextField18.setBounds(new Rectangle(193, 28, 57, 22));
    jLabel113.setText("������");
    jLabel113.setBounds(new Rectangle(356, 10, 52, 16));
    jTextField19.setText("jTextField1");
    jTextField19.setBounds(new Rectangle(270, 30, 57, 22));
    jTextField17.setText("jTextField4");
    jTextField17.setBounds(new Rectangle(107, 30, 60, 22));
    jLabel114.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel114.setText("2������");
    jLabel114.setBounds(new Rectangle(270, 7, 60, 16));
    jLabel115.setBounds(new Rectangle(189, 9, 77, 16));
    jLabel115.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel115.setText("500-5000Ԫ");
    jLabel116.setFont(new java.awt.Font("Dialog", 0, 14));
    jLabel116.setText("�¾����Ѷ�");
    jLabel117.setBounds(new Rectangle(94, 9, 92, 16));
    jLabel117.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel117.setText("5000-10000Ԫ");
    jTextField23.setBounds(new Rectangle(187, 28, 57, 22));
    jTextField23.setText("jTextField3");
    jLabel118.setBounds(new Rectangle(16, 8, 77, 16));
    jLabel118.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel118.setText("10000Ԫ����");
    jTextField25.setBounds(new Rectangle(352, 30, 57, 22));
    jTextField25.setText("jTextField5");
    jPanel5.setLayout(null);
    jPanel5.setBackground(new Color(217, 230, 236));
    jPanel5.setBorder(titledBorder2);
    jTextField22.setText("jTextField2");
    jTextField22.setBounds(new Rectangle(102, 27, 57, 22));
    jLabel119.setToolTipText("");
    jLabel119.setText("0");
    jLabel119.setBounds(new Rectangle(366, 8, 34, 16));
    jTextField21.setText("jTextField1");
    jTextField21.setBounds(new Rectangle(26, 26, 57, 22));
    jTextField24.setText("jTextField4");
    jTextField24.setBounds(new Rectangle(266, 28, 65, 22));
    jLabel1110.setFont(new java.awt.Font("Dialog", 0, 12));
    jLabel1110.setText("500Ԫ����");
    jLabel1110.setBounds(new Rectangle(269, 8, 58, 16));
    //jButton1.setToolTipText("");
    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setFont(new java.awt.Font("Dialog", 0, 13));
    jButton1.setText("����");
    jButton1.addActionListener(new CardUsePanel_jButton1_actionAdapter(this));
    jButton2.setBackground(new Color(151, 164, 203));
    jButton2.setFont(new java.awt.Font("Dialog", 0, 13));
    jButton2.setText("ȡ��");
    jButton2.addActionListener(new CardUsePanel_jButton2_actionAdapter(this));
    jButton3.setBackground(new Color(151, 164, 203));
    jButton3.setFont(new java.awt.Font("Dialog", 0, 13));
    jButton3.setToolTipText("");
    jButton3.setText("����");
    jButton3.addActionListener(new CardUsePanel_jButton3_actionAdapter(this));
    this.setBackground(new Color(217, 230, 236));
    jPanel1.add(jTextField1, null);
    jPanel1.add(jTextField2, null);
    jPanel1.add(jLabel4, null);
    jPanel1.add(jTextField3, null);
    jPanel1.add(jTextField5, null);
    jPanel1.add(jTextField4, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jLabel3, null);
    jPanel1.add(jLabel5, null);
    jPanel1.add(jLabel6, null);
    this.add(jLabel8,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(8, 53, 0, 26), 27, -4));
    this.add(jPanel2,  new GridBagConstraints(0, 3, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(8, 53, 0, 14), 462, 57));
    jPanel2.add(jLabel12, null);
    jPanel2.add(jLabel9, null);
    jPanel2.add(jTextField6, null);
    jPanel2.add(jTextField7, null);
    jPanel2.add(jTextField9, null);
    jPanel2.add(jTextField10, null);
    jPanel2.add(jLabel7, null);
    jPanel2.add(jTextField8, null);
    jPanel2.add(jLabel11, null);
    jPanel2.add(jLabel10, null);
    this.add(jLabel14,  new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(7, 53, 0, 16), 37, -4));
    this.add(jPanel3,  new GridBagConstraints(0, 5, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(7, 53, 0, 14), 462, 57));
    this.add(jLabel1,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(17, 53, 0, 63), 4, -4));
    this.add(jPanel1,  new GridBagConstraints(0, 1, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(6, 53, 0, 14), 462, 57));
    jPanel3.add(jLabel17, null);
    jPanel3.add(jLabel18, null);
    jPanel3.add(jTextField14, null);
    jPanel3.add(jTextField13, null);
    jPanel3.add(jLabel13, null);
    jPanel3.add(jTextField12, null);
    jPanel3.add(jLabel15, null);
    jPanel3.add(jTextField11, null);
    jPanel3.add(jTextField15, null);
    jPanel3.add(jLabel16, null);
    jPanel4.add(jLabel111, null);
    jPanel4.add(jTextField20, null);
    jPanel4.add(jLabel114, null);
    jPanel4.add(jLabel113, null);
    jPanel4.add(jTextField16, null);
    jPanel4.add(jTextField19, null);
    jPanel4.add(jTextField17, null);
    jPanel4.add(jTextField18, null);
    jPanel4.add(jLabel19, null);
    jPanel4.add(jLabel112, null);
    this.add(jButton3,  new GridBagConstraints(2, 10, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(16, 28, 19, 126), 11, 1));
    this.add(jButton2,  new GridBagConstraints(1, 10, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(15, 26, 19, 0), 13, 2));
    this.add(jButton1,  new GridBagConstraints(0, 10, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(17, 130, 19, 0), 13, 1));
    jPanel5.add(jTextField23, null);
    jPanel5.add(jTextField25, null);
    jPanel5.add(jLabel119, null);
    jPanel5.add(jTextField24, null);
    jPanel5.add(jLabel1110, null);
    jPanel5.add(jTextField21, null);
    jPanel5.add(jTextField22, null);
    jPanel5.add(jLabel117, null);
    jPanel5.add(jLabel115, null);
    jPanel5.add(jLabel118, null);
    this.add(jLabel116,  new GridBagConstraints(0, 8, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(6, 53, 0, 63), 18, -4));
    this.add(jPanel5,  new GridBagConstraints(0, 9, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 53, 0, 14), 462, 57));
    this.add(jLabel110,  new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(7, 53, 0, 63), 4, -4));
    this.add(jPanel4,  new GridBagConstraints(0, 7, 3, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 53, 0, 14), 462, 57));
   Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
  }
  public void connect() {
      try{
        String url ="jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
        String username = "sa";
        String password = "";
        con = DriverManager.getConnection(url, username, password);
      }
    catch(Exception e)
      {System.out.print("ϵͳ�������������С�");}
    }
    void loaddata()
    {
         try{
           query = "select * from UseInstance ";
           pstmt = con.prepareStatement(query);
           rs = pstmt.executeQuery();
           if (rs.next()) {
            jTextField1.setText(Integer.toString(rs.getInt(1)));
            jTextField2.setText(Integer.toString(rs.getInt(2)));
            jTextField3.setText(Integer.toString(rs.getInt(3)));
            jTextField4.setText(Integer.toString(rs.getInt(4)));
            jTextField5.setText(Integer.toString(rs.getInt(5)));
            jTextField6.setText(Integer.toString(rs.getInt(6)));
            jTextField7.setText(Integer.toString(rs.getInt(7)));
            jTextField8.setText(Integer.toString(rs.getInt(8)));
            jTextField9.setText(Integer.toString(rs.getInt(9)));
            jTextField10.setText(Integer.toString(rs.getInt(10)));
            jTextField11.setText(Integer.toString(rs.getInt(11)));
            jTextField12.setText(Integer.toString(rs.getInt(12)));
            jTextField13.setText(Integer.toString(rs.getInt(13)));
            jTextField14.setText(Integer.toString(rs.getInt(14)));
            jTextField15.setText(Integer.toString(rs.getInt(15)));
            jTextField16.setText(Integer.toString(rs.getInt(16)));
            jTextField17.setText(Integer.toString(rs.getInt(17)));
            jTextField18.setText(Integer.toString(rs.getInt(18)));
            jTextField19.setText(Integer.toString(rs.getInt(19)));
            jTextField20.setText(Integer.toString(rs.getInt(20)));
            jTextField21.setText(Integer.toString(rs.getInt(21)));
            jTextField22.setText(Integer.toString(rs.getInt(22)));
            jTextField23.setText(Integer.toString(rs.getInt(23)));
            jTextField24.setText(Integer.toString(rs.getInt(24)));
            jTextField25.setText(Integer.toString(rs.getInt(25)));
           }
         }
           catch(Exception ep)
              {   System.out.print("ϵͳ��������������1��");
              }
    }
  void update()
  {
      Yjcky3=jTextField1.getText();
      Yjcky3_15=jTextField2.getText();
      Yjcky15_5=jTextField3.getText();
      Yjcky5_1=jTextField4.getText();
      Yjcky1=jTextField5.getText();
      Yjljtz5=jTextField6.getText();
      Yjljtz2_5=jTextField7.getText();
      Yjljtz1_2=jTextField8.getText();
      Yjljtz1_1=jTextField9.getText();
      Yjljtz1=jTextField10.getText();
      Yhktzcs10=jTextField11.getText();
      Yhktzcs6_9=jTextField12.getText();
      Yhktzcs3_5=jTextField13.getText();
      Yhktzcs2=jTextField14.getText();
      Yhktzcs0=jTextField15.getText();
      Yjxfcs10=jTextField16.getText();
      Yjxfcs6_9=jTextField17.getText();
      Yjxfcs3_5= jTextField18.getText();
      Yjxfcs2=jTextField19.getText();
      Yjxfcs0=jTextField20.getText();
      Yjxf1=jTextField21.getText();
      Yjxf5_1= jTextField22.getText();
      Yjxf5_5=jTextField23.getText();
      Yjxf5=jTextField24.getText();
      Yjxf0=jTextField25.getText();
      try{
           query2="UPDATE  UseInstance SET Yjcky3=?, Yjcky3_15=?, Yjcky15_5=?, Yjcky5_1=?,   ";
           query2=query2+" Yjcky1=?, Yjljtz5=?,Yjljtz2_5=?,Yjljtz1_2=?, Yjljtz1_1=?, Yjljtz1=?,";
           query2=query2+" Yhktzcs10=?, Yhktzcs6_9=?, Yhktzcs3_5=?,Yhktzcs2=?, Yhktzcs0=?,";
           query2=query2+" Yjxfcs10=?, Yjxfcs6_9=?, Yjxfcs3_5=?, Yjxfcs2=?, Yjxfcs0=?, ";
           query2=query2+"Yjxf1=?, Yjxf5_1=?, Yjxf5_5=?, Yjxf5=?, Yjxf0=?";
           pstmt2 = con.prepareStatement(query2);
           pstmt2.setString(1,Yjcky3);
           pstmt2.setString(2, Yjcky3_15);
           pstmt2.setString(3,Yjcky15_5);
           pstmt2.setString(4,Yjcky5_1);
           pstmt2.setString(5, Yjcky1);
           pstmt2.setString(6,Yjljtz5);
           pstmt2.setString(7,Yjljtz2_5);
           pstmt2.setString(8,Yjljtz1_2);
           pstmt2.setString(9,Yjljtz1_1);
           pstmt2.setString(10,Yjljtz1);
           pstmt2.setString(11,Yhktzcs10);
           pstmt2.setString(12,Yhktzcs6_9);
           pstmt2.setString(13,Yhktzcs3_5);
           pstmt2.setString(14,Yhktzcs2);
           pstmt2.setString(15,Yhktzcs0);
           pstmt2.setString(16,Yjxfcs10);
           pstmt2.setString(17,Yjxfcs6_9);
           pstmt2.setString(18, Yjxfcs3_5);
           pstmt2.setString(19,Yjxfcs2);
           pstmt2.setString(20,Yjxfcs0);
           pstmt2.setString(21,Yjxf1);
           pstmt2.setString(22, Yjxf5_1);
           pstmt2.setString(23,Yjxf5_5);
           pstmt2.setString(24,Yjxf5);
           pstmt2.setString(25,Yjxf0);
           pstmt2.executeUpdate();
          JOptionPane.showMessageDialog(this,"�޸ĳɹ���","update",JOptionPane.INFORMATION_MESSAGE);
         }
         catch(SQLException ep)
         {System.out.print(ep.getMessage());
         }
  }
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  TitledBorder titledBorder9;
  GridBagLayout gridBagLayout1 = new GridBagLayout();

  void jButton1_actionPerformed(ActionEvent e) {
   int respond;
    respond = JOptionPane.showConfirmDialog(this,"ȷʵҪ�޸���","sure",JOptionPane.YES_NO_CANCEL_OPTION);
    if(respond==JOptionPane.YES_OPTION) update();
    else loaddata();
  }

  void jButton2_actionPerformed(ActionEvent e) {

    loaddata();
  }

  void jButton3_actionPerformed(ActionEvent e) {
   eventFrame.jSplitPane1.remove(eventFrame.jSplitPane1.getRightComponent());
   eventFrame.jSplitPane1.add(new helloPanel(),JSplitPane.RIGHT);
 }

}

class CardUsePanel_jButton1_actionAdapter implements java.awt.event.ActionListener {
  CardUsePanel adaptee;

  CardUsePanel_jButton1_actionAdapter(CardUsePanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class CardUsePanel_jButton2_actionAdapter implements java.awt.event.ActionListener {
  CardUsePanel adaptee;

  CardUsePanel_jButton2_actionAdapter(CardUsePanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class CardUsePanel_jButton3_actionAdapter implements java.awt.event.ActionListener {
  CardUsePanel adaptee;

  CardUsePanel_jButton3_actionAdapter(CardUsePanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}


