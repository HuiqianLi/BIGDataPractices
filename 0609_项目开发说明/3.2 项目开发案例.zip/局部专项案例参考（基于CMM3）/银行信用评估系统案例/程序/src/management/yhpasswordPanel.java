package management;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import com.borland.dx.dataset.*;
import com.borland.jbcl.layout.*;
import com.borland.dx.sql.dataset.*;
import java.awt.event.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class yhpasswordPanel extends JPanel {
  JLabel jLabel1 = new JLabel();
  JPasswordField jPasswordField1 = new JPasswordField();
  JLabel jLabel3 = new JLabel();
  JPasswordField jPasswordField3 = new JPasswordField();
  JLabel jLabel4 = new JLabel();
  JPasswordField jPasswordField4 = new JPasswordField();
  JButton jButton1 = new JButton();
  JButton jButton3 = new JButton();
  JLabel jLabel6 = new JLabel();
    JLabel jLabel7 = new JLabel();
  Database database1 = new Database();
  QueryDataSet queryDataSet1 = new QueryDataSet();
  QueryResolver queryResolver1 = new QueryResolver();

  PreparedStatement pstmt;
  Connection con;
  String query;
  ResultSet rs;
  String str;
  String strx;
  JLabel jLabel8 = new JLabel();
  JLabel jLabel5 = new JLabel();
  public yhpasswordPanel() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public yhpasswordPanel(String strx1) {
  strx=strx1;
    try {
    jbInit();
  }
  catch(Exception ex) {
    ex.printStackTrace();
  }
}



  void jbInit() throws Exception {
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 22));
    jLabel1.setForeground(SystemColor.activeCaption);
    jLabel1.setText(" �� �� �룺");
    jLabel1.setBounds(new Rectangle(15, 93, 138, 26));
    this.setLayout(null);
    this.setBackground(new Color(217, 230, 236));
    this.setDebugGraphicsOptions(0);
    this.setMaximumSize(new Dimension(2147483647, 2147483647));
    this.setOpaque(true);
    this.setToolTipText("");
    jPasswordField1.setText("");
    jPasswordField1.setBounds(new Rectangle(208, 98, 204, 26));
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 22));
    jLabel3.setForeground(SystemColor.activeCaption);
    jLabel3.setText("�����룺");
    jLabel3.setBounds(new Rectangle(18, 139, 124, 22));
    jPasswordField3.setText("");
    jPasswordField3.setBounds(new Rectangle(207, 136, 203, 26));
    jLabel4.setFont(new java.awt.Font("Dialog", 1, 22));
    jLabel4.setForeground(SystemColor.activeCaption);
    jLabel4.setText("ȷ�������룺");
    jLabel4.setBounds(new Rectangle(18, 178, 151, 26));
    jPasswordField4.setSelectionStart(15);
    jPasswordField4.setText("");
    jPasswordField4.setBounds(new Rectangle(206, 178, 203, 25));
    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setBounds(new Rectangle(206, 228, 73, 35));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 18));
    jButton1.setAlignmentY((float) 0.5);
    jButton1.setText("�޸�");
    jButton1.addActionListener(new yhpasswordPanel_jButton1_actionAdapter(this));
    jButton3.setBackground(new Color(151, 164, 203));
    jButton3.setBounds(new Rectangle(442, 178, 115, 27));
    jButton3.setFont(new java.awt.Font("Dialog", 1, 15));
    jButton3.setText("����������");
    jButton3.addActionListener(new yhpasswordPanel_jButton3_actionAdapter(this));
    jLabel6.setFont(new java.awt.Font("Dialog", 1, 22));
    jLabel6.setForeground(SystemColor.activeCaption);
    jLabel6.setBounds(new Rectangle(18, 277, 126, 34));
    jLabel6.setText("");
    jLabel7.setFont(new java.awt.Font("Dialog", 1, 22));
    jLabel7.setForeground(SystemColor.activeCaption);
    jLabel7.setText("������");
    jLabel7.setBounds(new Rectangle(14, 233, 128, 28));
    jLabel8.setBackground(Color.red);
    jLabel8.setFont(new java.awt.Font("Dialog", 1, 22));
    jLabel8.setForeground(Color.red);
    jLabel8.setBounds(new Rectangle(189, 279, 211, 31));
    jLabel5.setFont(new java.awt.Font("����", 1, 40));
    jLabel5.setText("�� �� �� �� �� ��");
    jLabel5.setBounds(new Rectangle(80, 0, 408, 48));
    this.add(jLabel6, null);
    this.add(jLabel8, null);
    this.add(jLabel5, null);
    this.add(jPasswordField4, null);
    this.add(jLabel4, null);
    this.add(jPasswordField3, null);
    this.add(jLabel3, null);
    this.add(jLabel7, null);
    this.add(jButton3, null);
    this.add(jButton1, null);
    this.add(jPasswordField1, null);
    this.add(jLabel1, null);

    Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
    String url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
    String username= "sa";
    String password= "";
    con = DriverManager.getConnection(url,username,password);

    jLabel6.setText("�޸Ľ����");

  }

  void jButton1_actionPerformed(ActionEvent e) {
    String str1=null;
    String str3=null;
    String str4=null;

    for(int i=0;i<jPasswordField1.getPassword().length;i++)
      str1+=jPasswordField1.getPassword()[i];
      str1=str1.substring(4);
    for(int i=0;i<jPasswordField3.getPassword().length;i++)
      str3+=jPasswordField3.getPassword()[i];
      str3=str3.substring(4);
    for(int i=0;i<jPasswordField4.getPassword().length;i++)
      str4+=jPasswordField4.getPassword()[i];
      str4=str4.substring(4);
       try{
         query = "select * from YHworker where YHworkerID=?";
         pstmt = con.prepareStatement(query);
         pstmt.setString(1,strx);
          rs=pstmt.executeQuery();

           if(rs.next()){
              str = rs.getString("Code");

              if(str1.equals(str))
               {
                  if(str3.equals(str4))
                  {
                    //�������룻
                    jLabel8.setText("��������ɹ�");
                    query = "update YHworker set Code="+ "\'"+str3+ "\'"+" where YHworkerID=?";
                    pstmt = con.prepareStatement(query);
                    pstmt.setString(1,strx);
                   rs=pstmt.executeQuery();
                  }
                 else
                  { jLabel8.setText("�����벻ƥ�䣬����������");
                   jPasswordField3.setText("");
                   jPasswordField4.setText("");
                  }
                }

              else
              {
                  jLabel8.setText("�����������������������");
                   jPasswordField1.setText("");
              }
           }
           else
             jLabel8.setText("û��ƥ����!");
       }
       catch(Exception ep)
       {
       }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    jPasswordField3.setText("");
    jPasswordField4.setText("");
  }
}

class yhpasswordPanel_jButton1_actionAdapter implements java.awt.event.ActionListener {
  yhpasswordPanel adaptee;

  yhpasswordPanel_jButton1_actionAdapter(yhpasswordPanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class yhpasswordPanel_jButton3_actionAdapter implements java.awt.event.ActionListener {
  yhpasswordPanel adaptee;

  yhpasswordPanel_jButton3_actionAdapter(yhpasswordPanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}
