package management;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import com.borland.dbswing.*;
import javax.swing.border.*;
import java.awt.event.*;
//import java.util.*;
import java.text.SimpleDateFormat;
import java.text.DateFormat;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class s12Panel extends JPanel {

  JLabel jLabel1 = new JLabel();
  JLabel jLabel01 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JComboBox jComboBox1 = new JComboBox();
  JLabel jLabel6 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel02 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel03 = new JLabel();
  JLabel jLabel04 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JPasswordField jPasswordField1 = new JPasswordField();
  PreparedStatement s12stmt1;
  PreparedStatement s12stmt2;
  Connection s12con;
  String s12sql,s12sql2;
  ResultSet s12rs,s12rs2;
  private double zvalue,zmoney,dmoney;
  private byte zvariety;
  private boolean islie=false;
  private String uid,uname,ucard,cid,cpwd,cGrade,zid,zname,zdate,zprice,zkind;

  JTextField jTextField2 = new JTextField();
  JLabel jLabel2 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JLabel jLabel8 = new JLabel();
  JTextField jTextField4 = new JTextField();
  JLabel jLabel11 = new JLabel();
  JTextField jTextField5 = new JTextField();


  public s12Panel() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
 //   border1 = BorderFactory.createLineBorder(SystemColor.controlText,1);
    jLabel1.setBackground(Color.pink);
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 30));
    jLabel1.setForeground(Color.blue);
    jLabel1.setAlignmentX((float) 0.0);
    jLabel1.setDebugGraphicsOptions(0);
    jLabel1.setOpaque(false);
    jLabel1.setRequestFocusEnabled(true);
    jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel1.setText("��/��Ѻ��ʱ������ϵͳ");
    jLabel1.setBounds(new Rectangle(0, 0, 486, 64));
    this.setLayout(null);
    this.setBackground(new Color(217, 230, 236));
    this.setBorder(null);
    this.setDebugGraphicsOptions(0);
    this.setOpaque(true);
    this.setRequestFocusEnabled(true);
    this.setVerifyInputWhenFocusTarget(true);
    jLabel01.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel01.setBorder(BorderFactory.createEtchedBorder());
    jLabel01.setDebugGraphicsOptions(0);
    jLabel01.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel01.setText("");
    jLabel01.setBounds(new Rectangle(95, 162, 126, 27));
    jLabel3.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel3.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel3.setText("���ÿ���");
    jLabel3.setBounds(new Rectangle(17, 59, 66, 26));
    jLabel4.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel4.setText("��/��Ѻ������");
    jLabel4.setBounds(new Rectangle(110, 344, 95, 27));
    jLabel5.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel5.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel5.setText("������ʽ");
    jLabel5.setBounds(new Rectangle(131, 301, 69, 30));
    jComboBox1.addItem("��Ѻ");
    jComboBox1.addItem("��Ѻ");
    jComboBox1.setFont(new java.awt.Font("Dialog", 0, 15));
    jComboBox1.setRequestFocusEnabled(true);
    jComboBox1.setToolTipText("");
    jComboBox1.setSelectedIndex(0);
    jComboBox1.setBounds(new Rectangle(221, 305, 104, 31));
    jLabel6.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel6.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel6.setText("�û���");
    jLabel6.setBounds(new Rectangle(38, 160, 56, 30));
    jTextField1.setBorder(BorderFactory.createLoweredBevelBorder());
    jTextField1.setToolTipText("");
    jTextField1.setText("");
    jTextField1.setBounds(new Rectangle(95, 59, 126, 26));
    jTextField1.addActionListener(new s12Panel_jTextField1_actionAdapter(this));
    jLabel7.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel7.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel7.setText("�û���");
    jLabel7.setBounds(new Rectangle(237, 162, 55, 27));
    jLabel02.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel02.setBorder(BorderFactory.createEtchedBorder());
    jLabel02.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel02.setText("");
    jLabel02.setBounds(new Rectangle(303, 160, 80, 29));
    jLabel9.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel9.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel9.setHorizontalTextPosition(SwingConstants.LEADING);
    jLabel9.setText("����");
    jLabel9.setBounds(new Rectangle(228, 58, 54, 29));
    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setBounds(new Rectangle(135, 104, 82, 36));
    jButton1.setFont(new java.awt.Font("Dialog", 0, 15));
    jButton1.setText("ȷ��");
    jButton1.addActionListener(new s12Panel_jButton1_actionAdapter(this));
    jButton2.setBackground(new Color(151, 164, 203));
    jButton2.setBounds(new Rectangle(282, 104, 67, 36));
    jButton2.setFont(new java.awt.Font("Dialog", 0, 15));
    jButton2.setText("��װ");
    jButton2.addActionListener(new s12Panel_jButton2_actionAdapter(this));
    jButton3.setBackground(new Color(151, 164, 203));
    jButton3.setBounds(new Rectangle(359, 494, 76, 38));
    jButton3.setFont(new java.awt.Font("Dialog", 0, 15));
    jButton3.setText("����");
    jButton3.addActionListener(new s12Panel_jButton3_actionAdapter(this));
    jLabel10.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel10.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel10.setText("����֤��");
    jLabel10.setBounds(new Rectangle(27, 206, 68, 29));
    jLabel03.setBorder(BorderFactory.createEtchedBorder());
    jLabel03.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel03.setText("");
    jLabel03.setBounds(new Rectangle(95, 206, 124, 28));
    jLabel04.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel04.setBorder(BorderFactory.createEtchedBorder());
    jLabel04.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel04.setText("");
    jLabel04.setBounds(new Rectangle(302, 204, 81, 30));
    jLabel14.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel14.setText("���õȼ�");
    jLabel14.setBounds(new Rectangle(230, 208, 62, 26));
    jButton4.setBackground(new Color(151, 164, 203));
    jButton4.setBounds(new Rectangle(85, 495, 79, 39));
    jButton4.setFont(new java.awt.Font("Dialog", 0, 15));
    jButton4.setText("����");
    jButton4.addActionListener(new s12Panel_jButton4_actionAdapter(this));
    jButton5.setBackground(new Color(151, 164, 203));
    jButton5.setBounds(new Rectangle(227, 494, 82, 40));
    jButton5.setFont(new java.awt.Font("Dialog", 0, 15));
    jButton5.setText("ȡ��");
    jButton5.addActionListener(new s12Panel_jButton5_actionAdapter(this));
    jPasswordField1.setText("");
    jPasswordField1.setBounds(new Rectangle(292, 58, 129, 29));
    jPasswordField1.addActionListener(new s12Panel_jPasswordField1_actionAdapter(this));
    jTextField2.setFont(new java.awt.Font("Dialog", 0, 15));
    jTextField2.setText("");
    jTextField2.setBounds(new Rectangle(221, 345, 103, 27));
    jTextField2.addActionListener(new s12Panel_jTextField2_actionAdapter(this));
    jLabel2.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel2.setText("��/��Ѻ����");
    jLabel2.setBounds(new Rectangle(99, 383, 107, 31));
    jTextField3.setFont(new java.awt.Font("Dialog", 0, 15));
    jTextField3.setText("");
    jTextField3.setBounds(new Rectangle(221, 385, 103, 29));
    jTextField3.addActionListener(new s12Panel_jTextField3_actionAdapter(this));
    jLabel8.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel8.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel8.setText("��/��Ѻ����");
    jLabel8.setBounds(new Rectangle(113, 429, 96, 31));
    jTextField4.setBackground(Color.white);
    jTextField4.setFont(new java.awt.Font("Dialog", 0, 15));
    jTextField4.setBounds(new Rectangle(221, 428, 104, 31));
    jTextField4.addActionListener(new s12Panel_jTextField4_actionAdapter(this));
    jLabel11.setFont(new java.awt.Font("Dialog", 0, 15));
    jLabel11.setHorizontalAlignment(SwingConstants.RIGHT);
    jLabel11.setText("��/��Ѻ����");
    jLabel11.setBounds(new Rectangle(100, 260, 103, 34));
    jTextField5.setText("");
    jTextField5.setBounds(new Rectangle(221, 262, 102, 31));
    jTextField5.addActionListener(new s12Panel_jTextField5_actionAdapter(this));
    this.add(jLabel1, null);
    this.add(jTextField1, null);
    this.add(jLabel3, null);
    this.add(jPasswordField1, null);
    this.add(jLabel9, null);
    this.add(jLabel01, null);
    this.add(jLabel6, null);
    this.add(jLabel10, null);
    this.add(jLabel02, null);
    this.add(jLabel7, null);
    this.add(jLabel04, null);
    this.add(jLabel14, null);
    this.add(jTextField2, null);
    this.add(jTextField3, null);
    this.add(jTextField4, null);
    this.add(jButton1, null);
    this.add(jButton2, null);
    this.add(jButton4, null);
    this.add(jLabel03, null);
    this.add(jTextField5, null);
    this.add(jComboBox1, null);
    this.add(jButton5, null);
    this.add(jButton3, null);
    this.add(jLabel11, null);
    this.add(jLabel5, null);
    this.add(jLabel4, null);
    this.add(jLabel2, null);
    this.add(jLabel8, null);
    Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
  }

  void countCGrade(double money){
    if(money>=50000) cGrade="A";
      else if(money>=40000) cGrade="B";
      else if(money>=30000) cGrade="C";
      else if(money>=20000) cGrade="D";
      else if(money>=10000) cGrade="E";
      else if(money>=5000)  cGrade="F";
      else if(money>=2000)  cGrade="G";
      else                  cGrade="H";
  }

  void setempty(){
    jLabel01.setText(null);
    jLabel02.setText(null);
    jLabel03.setText(null);
    jLabel04.setText(null);
    jTextField2.setText(null);
    jTextField3.setText(null);
    jTextField4.setText(null);
    jTextField5.setText(null);
  }

int getmoney(char ch){
  switch(ch){
    case 'A':   return 50000;
    case 'B':   return 40000;
    case 'C':   return 30000;
    case 'D':   return 20000;
    case 'E':   return 10000;
    case 'F':   return 5000;
    case 'G':   return 2000;
    case 'H':   return 0 ;
    default :  return -1;
  }
}

  void jButton1_actionPerformed(ActionEvent e) {
    try{
      if(jTextField1.getText().length()==0){
        JOptionPane.showMessageDialog(this,"���ÿ��Ų���Ϊ�գ�","����",JOptionPane.WARNING_MESSAGE);
        // focus     jTextField1.se();
        return;
      }
        else if(jPasswordField1.getPassword().length==0){
          JOptionPane.showMessageDialog(this,"���벻��Ϊ�գ�","����",JOptionPane.WARNING_MESSAGE);
          //set focus
          return;
        }
      cid=jTextField1.getText();
      cpwd="";
      for(int i=0;i<jPasswordField1.getPassword().length;i++)
        cpwd+=jPasswordField1.getPassword()[i];
      jTextField1.setText(null);
      jPasswordField1.setText(null);
      String url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
      String username= "sa";
      String password= "";
      s12con = DriverManager.getConnection(url,username,password);
      s12sql="select UserId,CreditcardGrade from Creditcard where CreditcardId=? and CreditcardCode=?";
      s12stmt1 = s12con.prepareStatement(s12sql);
      s12stmt1.setString(1,cid);
      s12stmt1.setString(2,cpwd);
      s12rs=s12stmt1.executeQuery();
      if(s12rs.next()){
        uid=s12rs.getString(1);
        cGrade=s12rs.getString(2);
        s12sql="select UserName,UserCard from Users where UserId=?";
        s12sql2="select ZdId from ZDthing where UserId=?";
        s12stmt1 = s12con.prepareStatement(s12sql);
        s12stmt2=s12con.prepareStatement(s12sql2);
        s12stmt1.setString(1,uid);
        s12stmt2.setString(1,uid);
        s12rs=s12stmt1.executeQuery();
        s12rs2=s12stmt2.executeQuery();
        if(s12rs.next()){
          uname=s12rs.getString(1);
          ucard=s12rs.getString(2);
          jLabel01.setText(uid);
          jLabel02.setText(uname);
          jLabel03.setText(ucard);
          jLabel04.setText(cGrade);
        }
        else{
          JOptionPane.showMessageDialog(this,"ϵͳ���������������룡","����",JOptionPane.WARNING_MESSAGE);
          //set focus=textfield1;
          return;
        }
        if(s12rs2.next()){
          islie=true;
          zid=s12rs2.getString(1);
          jTextField5.setText(zid);
          int y=java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
          int m=java.util.Calendar.getInstance().get(java.util.Calendar.MONTH)+1;
          int d= java.util.Calendar.getInstance().get( java.util.Calendar.DATE);
          String dd=String.valueOf(y)+"-"+String.valueOf(m)+"-"+String.valueOf(d);
          jTextField4.setText(dd);
        }
        else{
          islie=false;
          JOptionPane.showMessageDialog(this,"���û����޵�Ѻ���Ϊ�������µĵ�Ѻ���ţ�","֪ͨ",JOptionPane.WARNING_MESSAGE);
          int y=java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
          int m=java.util.Calendar.getInstance().get(java.util.Calendar.MONTH)+1;
          int d= java.util.Calendar.getInstance().get( java.util.Calendar.DATE);
          String dd=String.valueOf(y)+"-"+String.valueOf(m)+"-"+String.valueOf(d);
          jTextField4.setText(dd);
          return;
        }
      }
      else {
        JOptionPane.showMessageDialog(this,"���ÿ��Ż��������","����",JOptionPane.ERROR_MESSAGE);
      //set focus
        return;
      }
  }catch(SQLException ee){System.out.println("1   "+ee.getMessage());}
  catch(Exception ep){System.out.println("2  "+ep.getMessage());}
  }

  void jButton2_actionPerformed(ActionEvent e) {
    jTextField1.setText(null);
    jPasswordField1.setText(null);
  }

  void jButton3_actionPerformed(ActionEvent e) {
    setempty();
    eventFrame.jSplitPane1.remove(eventFrame.jSplitPane1.getRightComponent());
    eventFrame.jSplitPane1.add(new helloPanel(),JSplitPane.RIGHT);
  }

  void jButton4_actionPerformed(ActionEvent e) {
    try{
      if(jTextField5.getText().length()==0){
        JOptionPane.showMessageDialog(this,"��Ѻ���Ų���Ϊ�գ�","����",JOptionPane.WARNING_MESSAGE);
        //set focus
        return;
      }
      else if(jTextField2.getText().length()==0){
        JOptionPane.showMessageDialog(this,"��Ѻ�����Ʋ���Ϊ�գ�","����",JOptionPane.WARNING_MESSAGE);
        //set focus
        return;
      }
      else if(jTextField3.getText().length()==0){
        JOptionPane.showMessageDialog(this,"���ڲ���Ϊ�գ�","����",JOptionPane.WARNING_MESSAGE);
        //set focus
        return;
      }
      if(islie==false)
        zid=jTextField5.getText();
      zname=jTextField2.getText();
      zprice=jTextField3.getText();
      zkind=(String)jComboBox1.getSelectedItem();
      zvariety=(byte)jComboBox1.getSelectedIndex();
      zdate=jTextField4.getText();
      zvalue=Double.parseDouble(zprice);
      java.sql.Date zday=java.sql.Date.valueOf(zdate);
      dmoney=zvalue*0.6;
      zmoney=zvalue*0.9;

      String url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
      String username= "sa";
      String password= "";
      s12con = DriverManager.getConnection(url,username,password);
      if(islie==true){//geng xin
          s12sql="update ZDthing set Zdname=?,Zdprice=?,Zddate=?,Zdstate=? where ZdId=?";
          s12stmt1 = s12con.prepareStatement(s12sql);
          s12stmt1.setString(1,zname);
          s12stmt1.setDouble(2,zvalue);
          s12stmt1.setDate(3,zday);
          s12stmt1.setString(4,zkind);
          s12stmt1.setString(5,zid);
          s12stmt1.executeUpdate();
      }
      else{
        s12sql="insert into ZDthing values(?,?,?,?,?,?)";
        s12stmt1 = s12con.prepareStatement(s12sql);
        s12stmt1.setString(1,zid);
        s12stmt1.setString(2,uid);
        s12stmt1.setString(3,zname);
        s12stmt1.setDouble(4,zvalue);
        s12stmt1.setDate(5,zday);
        s12stmt1.setString(6,zkind);
        s12stmt1.executeUpdate();
      }
      switch(zvariety){
        case 0 :
          countCGrade(zmoney);
          s12sql="update Creditcard set CreditcardGrade=? where CreditcardId=?";
          s12stmt1 = s12con.prepareStatement(s12sql);
          s12stmt1.setString(1,cGrade);
          s12stmt1.setString(2,cid);
          s12stmt1.executeUpdate();
          JOptionPane.showMessageDialog(this,"�����ɹ�\n"+"���õȼ��ѵ���Ϊ�� "+cGrade+"\n���ö���ѵ���Ϊ�� "+getmoney(cGrade.toCharArray()[0])+" Ԫ","֪ͨ",JOptionPane.INFORMATION_MESSAGE);
          setempty();
          break;
        case 1 :
          countCGrade(dmoney);
          s12sql="update Creditcard set CreditcardGrade=? where CreditcardId=?";
          s12stmt1 = s12con.prepareStatement(s12sql);
          s12stmt1.setString(1,cGrade);
          s12stmt1.setString(2,cid);
          s12stmt1.executeUpdate();
          JOptionPane.showMessageDialog(this,"�����ɹ�\n"+"���õȼ��ѵ���Ϊ�� "+cGrade+"\n���ö���ѵ���Ϊ�� "+getmoney(cGrade.toCharArray()[0])+" Ԫ","֪ͨ",JOptionPane.INFORMATION_MESSAGE);
          setempty();
          break;
      }
    }catch(SQLException ee){//���ݿ����
      JOptionPane.showMessageDialog(this,"���ݿ���������飡","����",JOptionPane.ERROR_MESSAGE);
    }
    catch(Exception ep){//�������
      String errmsg=ep.getMessage();
      System.out.println(errmsg);
      JOptionPane.showMessageDialog(this,"�������","����",JOptionPane.ERROR_MESSAGE);
    }
  }

  void jButton5_actionPerformed(ActionEvent e) {
    setempty();
  }

  void jPasswordField1_actionPerformed(ActionEvent e) {
    jButton1_actionPerformed(e);
  }

  void jTextField1_actionPerformed(ActionEvent e) {
    jButton1_actionPerformed(e);
  }

  void jTextField2_actionPerformed(ActionEvent e) {
    jButton4_actionPerformed(e);
  }

  void jTextField5_actionPerformed(ActionEvent e) {
    jButton4_actionPerformed(e);
  }

  void jTextField3_actionPerformed(ActionEvent e) {
    jButton4_actionPerformed(e);
  }

  void jTextField4_actionPerformed(ActionEvent e) {
    jButton4_actionPerformed(e);
  }

}

class s12Panel_jButton1_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jButton1_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class s12Panel_jButton2_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jButton2_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class s12Panel_jButton3_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jButton3_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class s12Panel_jButton4_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jButton4_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton4_actionPerformed(e);
  }
}

class s12Panel_jButton5_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jButton5_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton5_actionPerformed(e);
  }
}

class s12Panel_jPasswordField1_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jPasswordField1_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jPasswordField1_actionPerformed(e);
  }
}

class s12Panel_jTextField1_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jTextField1_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jTextField1_actionPerformed(e);
  }
}

class s12Panel_jTextField2_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jTextField2_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jTextField2_actionPerformed(e);
  }
}

class s12Panel_jTextField5_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jTextField5_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jTextField5_actionPerformed(e);
  }
}

class s12Panel_jTextField3_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jTextField3_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jTextField3_actionPerformed(e);
  }
}

class s12Panel_jTextField4_actionAdapter implements java.awt.event.ActionListener {
  s12Panel adaptee;

  s12Panel_jTextField4_actionAdapter(s12Panel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jTextField4_actionPerformed(e);
  }
}
