package management;

import java.awt.*;
import javax.swing.*;
import com.borland.dbswing.*;
import com.borland.dx.sql.dataset.*;
import java.sql.*;
import com.borland.dx.dataset.*;
import com.borland.jbcl.layout.*;
import com.borland.dx.sql.dataset.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class SetPriority extends JPanel {
  JLabel jLabel1 = new JLabel();
  Database database1 = new Database();
  TableScrollPane tableScrollPane1 = new TableScrollPane();
  JdbStatusLabel jdbStatusLabel1 = new JdbStatusLabel();
  QueryResolver queryResolver1 = new QueryResolver();
  JLabel jLabel2 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();

  PreparedStatement pstmt;
  Connection con;
  String query;
  ResultSet rs;
  String str1;
  String str2;
  Column column1 = new Column();
  Column column2 = new Column();
  Column column3 = new Column();
  QueryDataSet queryDataSet1 = new QueryDataSet();
  JdbTable jdbTable1 = new JdbTable();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JLabel jLabel7 = new JLabel();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();



  public SetPriority() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    this.setLayout(null);
    jLabel1.setFont(new java.awt.Font("����", 1, 28));
    jLabel1.setText("������ԱȨ������");
    jLabel1.setBounds(new Rectangle(135, 2, 336, 48));
//    jdbNavToolBar1.setNextFocusableComponent(null);
    tableScrollPane1.getViewport().setBackground(new Color(217, 230, 236));
    tableScrollPane1.setRequestFocusEnabled(true);
    tableScrollPane1.setBounds(new Rectangle(37, 119, 444, 89));
    database1.setConnection(new com.borland.dx.sql.dataset.ConnectionDescriptor("jdbc:microsoft:sqlserver://LOCALHOST:1433;DatabaseName=CCES", "sa", "", false, "com.microsoft.jdbc.sqlserver.SQLServerDriver"));
    database1.setTransactionIsolation(java.sql.Connection.TRANSACTION_READ_COMMITTED);
    database1.setUseSpacePadding(false);
    database1.setDatabaseName("");
    jdbStatusLabel1.setVisible(false);
    jdbStatusLabel1.setText("");
    jdbStatusLabel1.setDisplayMessages(true);
    jdbStatusLabel1.setBounds(new Rectangle(11, 149, 365, 21));
    queryResolver1.setDatabase(database1);
    queryResolver1.setResolverQueryTimeout(0);
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 18));
    jLabel2.setText("����Ȩ�޺ţ�");
    jLabel2.setBounds(new Rectangle(71, 88, 118, 23));
    jTextField1.setText("");
    jTextField1.setBounds(new Rectangle(179, 84, 129, 24));
    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setBounds(new Rectangle(319, 83, 73, 23));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 15));
    jButton1.setText("ȷ ��");
    jButton1.addActionListener(new SetPriority_jButton1_actionAdapter(this));
    jButton2.setBackground(new Color(151, 164, 203));
    jButton2.setBounds(new Rectangle(406, 83, 71, 22));
    jButton2.setFont(new java.awt.Font("Dialog", 1, 15));
    jButton2.setActionCommand("�� ��");
    jButton2.setText("�� ��");
    jButton2.addActionListener(new SetPriority_jButton2_actionAdapter(this));
    column1.setCaption("Ȩ��ID");
   column1.setColumnName("PopedomId");
   column1.setDataType(com.borland.dx.dataset.Variant.STRING);
   column1.setPrecision(40);
   column1.setSchemaName("dbo");
   column1.setTableName("Popedom");
   column1.setServerColumnName("PopedomId");
   column1.setSqlType(12);

    column2.setCaption("Ȩ������");
    column2.setColumnName("PopedomName");
    column2.setDataType(com.borland.dx.dataset.Variant.STRING);
    column2.setPrecision(40);
    column2.setSchemaName("dbo");
    column2.setTableName("Popedom");
    column2.setServerColumnName("PopedomName");
    column2.setSqlType(12);

    column3.setCaption("Ȩ������");
    column3.setColumnName("PopedomExplain");
    column3.setDataType(com.borland.dx.dataset.Variant.STRING);
    column3.setPrecision(40);
    column3.setSchemaName("dbo");
    column3.setTableName("Popedom");
    column3.setServerColumnName("PopedomExplain");
    column3.setSqlType(12);

    //PopedomExplain.setCalcType(com.borland.dx.dataset.CalcType.NO_CALC);
    this.setBackground(new Color(217, 230, 236));
    queryDataSet1.setColumns(new Column[] {column1,column2,column3});
    queryDataSet1.setQuery(new com.borland.dx.sql.dataset.QueryDescriptor(database1, "SELECT * FROM Popedom", null, true, Load.ALL));
    jdbTable1.setDataSet(queryDataSet1);
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 18));
    jLabel3.setText("Ȩ���޸ģ�");
    jLabel3.setBounds(new Rectangle(34, 225, 95, 18));
    jLabel5.setFont(new java.awt.Font("Dialog", 1, 18));
    jLabel5.setRequestFocusEnabled(true);
    jLabel5.setText("Ȩ�����ƣ�");
    jLabel5.setBounds(new Rectangle(52, 256, 104, 18));
    jLabel6.setFont(new java.awt.Font("Dialog", 1, 18));
    jLabel6.setText("Ȩ��˵����");
    jLabel6.setBounds(new Rectangle(52, 292, 100, 18));
    jTextField3.setText("");
    jTextField3.setBounds(new Rectangle(189, 255, 254, 22));
    jTextField4.setText("");
    jTextField4.setBounds(new Rectangle(187, 290, 255, 21));
    jLabel7.setFont(new java.awt.Font("Dialog", 1, 18));
    jLabel7.setText("Ȩ����ʾ��");
    jLabel7.setBounds(new Rectangle(35, 52, 109, 18));
    jButton3.setBackground(new Color(151, 164, 203));
    jButton3.setBounds(new Rectangle(145, 332, 97, 25));
    jButton3.setFont(new java.awt.Font("Dialog", 1, 15));
    jButton3.setText("ȷ������");
    jButton3.addActionListener(new SetPriority_jButton3_actionAdapter(this));
    jButton4.setBackground(new Color(151, 164, 203));
    jButton4.setBounds(new Rectangle(381, 330, 79, 25));
    jButton4.setFont(new java.awt.Font("Dialog", 1, 15));
    jButton4.setText("���");
    jButton4.addActionListener(new SetPriority_jButton4_actionAdapter(this));
    jButton5.setBackground(new Color(151, 164, 203));
    jButton5.setBounds(new Rectangle(259, 331, 104, 25));
    jButton5.setFont(new java.awt.Font("Dialog", 1, 15));
    jButton5.setText("ȷ���޸�");
    jButton5.addActionListener(new SetPriority_jButton5_actionAdapter(this));
    this.add(jdbStatusLabel1, null);
    this.add(jLabel7, null);
    this.add(tableScrollPane1, null);
    this.add(jLabel2, null);
    this.add(jTextField1, null);
    this.add(jButton1, null);
    this.add(jButton2, null);
    this.add(jLabel3, null);
    this.add(jLabel1, null);
    this.add(jLabel5, null);
    this.add(jLabel6, null);
    this.add(jTextField4, null);
    this.add(jButton5, null);
    this.add(jButton3, null);
    this.add(jButton4, null);
    this.add(jTextField3, null);
    tableScrollPane1.getViewport().add(jdbTable1, null);
    queryDataSet1.close();
    queryDataSet1.refresh();
    jdbTable1.setDataSet(null);


    Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
    String url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
    String username= "sa";
    String password= "";
    con = DriverManager.getConnection(url,username,password);
    //con = DriverManager.getConnection(url);
    str2="select * from Popedom";

  }

  void jButton1_actionPerformed(ActionEvent e) {
//    jdbStatusLabel1.setText("");
    try{
     query = "select * from Popedom where PopedomId=?";
     str2=jTextField1.getText();
     //Integer.parseInt(str2,num);
     pstmt = con.prepareStatement(query);
    // pstmt.setInt(1,num);
     pstmt.setString(1,str2);
     rs=pstmt.executeQuery();
         if(rs.next()){
           queryDataSet1.close();
           str1 = rs.getString("PopedomId");
                // num=rs.getInt("PopedomId");
                 // str1 ="select STUDENTNO as"+ "\'"+"ѧ��" +"\'"+",STUDENTNAME as" + "\'"+"����" +"\'"+",STUDENTAGE as"+ "\'"+"����" +"\'"+",STUDENTSEX as"+ "\'"+"�Ա�" +"\'"+",STUENTRACE as"+ "\'"+"����" +"\'"+",STUDENTSPECIATION as"+ "\'"+"רҵ" +"\'"+"from student where STUDENTNO="+ "\'" + str1 + "\'";
                  str1="select * from Popedom where PopedomId="+ "\'" + str1 + "\'";
                  queryDataSet1.setQuery(new com.borland.dx.sql.dataset.QueryDescriptor(database1, str1, null, true, Load.ALL));
                  queryDataSet1.refresh();
                  jdbTable1.setDataSet(queryDataSet1);
                  jdbTable1.repaint();
         }
         else{
          jTextField1.setText("û��ƥ����!");
          queryDataSet1.close();
          queryDataSet1.refresh();
          jdbTable1.setDataSet(null);
          jdbTable1.repaint();
      }

      }
        catch(Exception ef)
       { System.out.print("ϵͳ�������������С�");
        }

  }

  void jButton2_actionPerformed(ActionEvent e) {
    jdbStatusLabel1.setText("");
    jTextField1.setText("");
    /*queryDataSet1.close();
    jdbTable1.setDataSet(null);
    queryDataSet1.setQuery(new com.borland.dx.sql.dataset.QueryDescriptor(database1, str2, null, true, Load.ALL));
    queryDataSet1.refresh();
    jdbNavToolBar1.setDataSet(queryDataSet1);
    jdbStatusLabel1.setDataSet(queryDataSet1);
    jdbTable1.setDataSet(queryDataSet1);
    jdbTable1.repaint();*/
    queryDataSet1.close();
    queryDataSet1.refresh();
    jdbTable1.setDataSet(null);
    //jdbTable1.repaint();


  }

  void jButton3_actionPerformed(ActionEvent e) {

   String  qxName = jTextField3.getText();
   String  qxExplain = jTextField4.getText();
   String qxID1;

   qxID1 = "insert into Popedom(PopedomName,PopedomExplain) values('"+qxName+"\'"+",'"+qxExplain+"')";
   //qxID = "insert into Popedom values('3','dkkdj','dhkjfhkjdefh')";
   try{
     String url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
     String username= "sa";
     String password= "";
     con = DriverManager.getConnection(url,username,password);
     pstmt = con.prepareStatement(qxID1);
     rs = pstmt.executeQuery();
 }
 catch(Exception exx){

 }

  }

  void jButton4_actionPerformed(ActionEvent e) {

    jTextField3.setText("");
    jTextField4.setText("");
  }

  void jButton5_actionPerformed(ActionEvent e) {

    String qxName = jTextField3.getText();
    String qxExplain = jTextField4.getText();
    String qxID1;


    try {
      String url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
      String username = "sa";
      String password = "";
      con = DriverManager.getConnection(url, username, password);
      Statement ps;
      qxID1 = "Update Popedom Set PopedomName='"+qxName+"', PopedomExplain ='"+qxExplain+"' where PopedomId ='"+jTextField1.getText() +"\'";
      ps = con.createStatement();
      //pstmt.setString(1, qxID);
      //pstmt.setString(2, qxName);
      //pstmt.setString(3, qxExplain);
     ps.execute(qxID1);
    }
    catch (Exception exm) {}
  }
}

class SetPriority_jButton1_actionAdapter implements java.awt.event.ActionListener {
  SetPriority adaptee;

  SetPriority_jButton1_actionAdapter(SetPriority adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class SetPriority_jButton2_actionAdapter implements java.awt.event.ActionListener {
  SetPriority adaptee;

  SetPriority_jButton2_actionAdapter(SetPriority adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class SetPriority_jButton3_actionAdapter implements java.awt.event.ActionListener {
  SetPriority adaptee;

  SetPriority_jButton3_actionAdapter(SetPriority adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class SetPriority_jButton4_actionAdapter implements java.awt.event.ActionListener {
  SetPriority adaptee;

  SetPriority_jButton4_actionAdapter(SetPriority adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton4_actionPerformed(e);
  }
}

class SetPriority_jButton5_actionAdapter implements java.awt.event.ActionListener {
  SetPriority adaptee;

  SetPriority_jButton5_actionAdapter(SetPriority adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton5_actionPerformed(e);
  }
}
