package management;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class evFrame1 extends JFrame implements TreeSelectionListener {
     JSplitPane jSplitPane1;
     JTree jTree1=new JTree();
     helloPanel helloPanel1;
     basicInf basic;
     Notice notice;
    String CreditcardId;
    UserHelp help;
    ChangePassword code;
    Dialog1 dialog;
    GridBagLayout gridBagLayout1 = new GridBagLayout();

  public evFrame1() {
    try {
     jbInit();
   }
   catch(Exception e) {
     e.printStackTrace();
   }
  }
  public evFrame1(String strx1) {
   CreditcardId=strx1;
    try {
   jbInit();
 }
 catch(Exception e) {
   e.printStackTrace();
 }
}



  private void jbInit() throws Exception {
    jSplitPane1 = new JSplitPane();
      this.getContentPane().setLayout(gridBagLayout1);
      this.getContentPane().add(jSplitPane1,  new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
              ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 388, 304));
      jSplitPane1.add(jTree1, JSplitPane.LEFT);
      jSplitPane1.setDividerLocation(150);
      helloPanel1=new helloPanel();
      basic=new basicInf(CreditcardId);
      notice=new Notice(CreditcardId);
      help=new UserHelp(CreditcardId,"huadi-1k32");
      code=new ChangePassword(CreditcardId);
      dialog=new Dialog1();

      /*
      reportPanel1=new  reportPanel(strx,ip);
      searchPanel1=new searchPanel3(strx,ip);
     */
      DefaultMutableTreeNode root = new DefaultMutableTreeNode("���ÿ�����ϵͳ");
     DefaultMutableTreeNode bitchThing = new DefaultMutableTreeNode("�û�������Ϣ��ѯ");
     root.add(bitchThing);
     bitchThing = new DefaultMutableTreeNode("�û�����֪ͨ��ѯ");
     root.add(bitchThing);
     bitchThing = new DefaultMutableTreeNode("�����޸�");
     root.add(bitchThing);
     bitchThing = new DefaultMutableTreeNode("����");
     root.add(bitchThing);
     bitchThing = new DefaultMutableTreeNode("�˳�ϵͳ");
     root.add(bitchThing);
     jTree1 = new JTree(root);
     jSplitPane1.add(jTree1, JSplitPane.LEFT);
     jSplitPane1.add(helloPanel1,JSplitPane.RIGHT);
     jTree1.addTreeSelectionListener(this);
     int mode = TreeSelectionModel.SINGLE_TREE_SELECTION;
     jTree1.getSelectionModel().setSelectionMode(mode);
  }

  public void valueChanged(TreeSelectionEvent e) {
    /**@todo Implement this javax.swing.event.TreeSelectionListener method*/
   // throw new java.lang.UnsupportedOperationException("Method valueChanged() not yet implemented.");
   String node=jTree1.getLastSelectedPathComponent().toString();
        if(node.equals("���ÿ�����ϵͳ")){
          jSplitPane1.remove(jSplitPane1.getRightComponent());
          jSplitPane1.add(helloPanel1,JSplitPane.RIGHT);
          jSplitPane1.setDividerLocation(150);
        }

        if(node.equals("�û�������Ϣ��ѯ")){
                jSplitPane1.remove(jSplitPane1.getRightComponent());
                jSplitPane1.add(basic,JSplitPane.RIGHT);
                jSplitPane1.setDividerLocation(150);
              }

        if(node.equals("�û�����֪ͨ��ѯ")){
         jSplitPane1.remove(jSplitPane1.getRightComponent());
         jSplitPane1.add(notice,JSplitPane.RIGHT);
         jSplitPane1.setDividerLocation(150);
       }

       if(node.equals("�����޸�")){
            jSplitPane1.remove(jSplitPane1.getRightComponent());
            jSplitPane1.add(code,JSplitPane.RIGHT);
            jSplitPane1.setDividerLocation(150);
          }

        if(node.equals("����")){
           jSplitPane1.remove(jSplitPane1.getRightComponent());
           jSplitPane1.add(help,JSplitPane.RIGHT);
           jSplitPane1.setDividerLocation(150);
         }

       if(node.equals("�˳�ϵͳ")){
         dialog.setBounds(250,200,350,145);
         dialog.show(true);
       }
 }

}
