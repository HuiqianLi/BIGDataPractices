package management;

import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import java.util.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class eventFrame extends JFrame implements TreeSelectionListener {
   static JSplitPane jSplitPane1;
   JTree jTree1=new JTree();
   helloPanel helloPanel1;
   s12Panel s12Panel1;
   testPanel testPanel1;
   sendNotice sen;
   WarrantorCheck WarrantorCheck1;
   ZdthingPanel ZdthingPanel1;
   yhpasswordPanel yhpasswordPanel1;
   FreeValidityCheckPanel FreeValidityCheckPanel1;
   SetPriority SetPriority1;
   FreeHalfAdjust FreeHalfAdjust1;
   CreditAdjustSetPanel CreditAdjustSetPanel1;
   GuaranteeBetimesAdjust GuaranteeBetimesAdjust1;
   ExitSystem ExitSystem1;
  /*
   informPanel2 informPanel1;
   coursePanel coursePanel1;
   scorePanel scorePanel1;
   searchPanel2 searchPanel1;
   statisticPanel2 statisticPanel1;
   */
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  String YHworkerID;

  public eventFrame() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public eventFrame(String str) {
    YHworkerID=str;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
}

  private void jbInit() throws Exception {
     jSplitPane1 = new JSplitPane();
    this.getContentPane().setLayout(gridBagLayout1);
    this.getContentPane().add(jSplitPane1,  new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 388, 304));
    jSplitPane1.add(jTree1, JSplitPane.LEFT);
    jSplitPane1.setDividerLocation(150);
    helloPanel1=new helloPanel();
    WarrantorCheck1=new WarrantorCheck(YHworkerID);
    ZdthingPanel1=new ZdthingPanel(YHworkerID);
    testPanel1=new testPanel();
    yhpasswordPanel1=new yhpasswordPanel(YHworkerID);
    FreeValidityCheckPanel1=new FreeValidityCheckPanel(YHworkerID);
    SetPriority1=new SetPriority();
    s12Panel1=new s12Panel();
    sen=new sendNotice();
    FreeHalfAdjust1=new FreeHalfAdjust();
    CreditAdjustSetPanel1=new CreditAdjustSetPanel();
    GuaranteeBetimesAdjust1=new GuaranteeBetimesAdjust();
    ExitSystem1=new ExitSystem();
    /*
    informPanel1=new informPanel2(ip);
    coursePanel1=new coursePanel(ip);
    scorePanel1=new scorePanel(ip);
    searchPanel1=new searchPanel2(ip);
    statisticPanel1=new statisticPanel2(ip);
  */
    DefaultMutableTreeNode root = new DefaultMutableTreeNode("���ÿ�����ϵͳ");
    DefaultMutableTreeNode chose;
   DefaultMutableTreeNode bitchThing = new DefaultMutableTreeNode("�쿨");
    chose=new DefaultMutableTreeNode("�ⵣ���쿨");
     bitchThing.add(chose);
      chose.add(new DefaultMutableTreeNode("�����Ч��"));
      chose.add(new DefaultMutableTreeNode("�ⵣ������"));

    chose=new DefaultMutableTreeNode("��֤�����쿨");
    bitchThing.add(chose);
    // chose.add(new DefaultMutableTreeNode("��鵣�����ʸ�"));
     chose.add(new DefaultMutableTreeNode("��֤�����쿨"));

    chose=new DefaultMutableTreeNode("����Ѻ�쿨");
     bitchThing.add(chose);
      chose.add(new DefaultMutableTreeNode("����Ѻ����"));
   root.add(bitchThing);
   bitchThing = new DefaultMutableTreeNode("���õ���");
   bitchThing.add(new DefaultMutableTreeNode("�ⵣ���������"));
   bitchThing.add(new DefaultMutableTreeNode("��֤������ʱ����"));
   bitchThing.add(new DefaultMutableTreeNode("����Ѻ��ʱ����"));
   bitchThing.add(new DefaultMutableTreeNode("����֪ͨ"));
   root.add(bitchThing);
   bitchThing = new DefaultMutableTreeNode("�����޸�");
   bitchThing.add(new DefaultMutableTreeNode("�쿨����������׼�޸�"));
   bitchThing.add(new DefaultMutableTreeNode("�������ֱ�׼�޸�"));
   root.add(bitchThing);
   bitchThing = new DefaultMutableTreeNode("Ȩ������");
   root.add(bitchThing);
   bitchThing = new DefaultMutableTreeNode("�����޸�");
   root.add(bitchThing);
   bitchThing = new DefaultMutableTreeNode("�˳�ϵͳ");
   root.add(bitchThing);
   jTree1 = new JTree(root);
   jSplitPane1.add(jTree1, JSplitPane.LEFT);
   jSplitPane1.add(helloPanel1,JSplitPane.RIGHT);
   jTree1.addTreeSelectionListener(this);
   int mode = TreeSelectionModel.SINGLE_TREE_SELECTION;
   jTree1.getSelectionModel().setSelectionMode(mode);

  }
  public void valueChanged(TreeSelectionEvent e) {
    /**@todo Implement this javax.swing.event.TreeSelectionListener method*/
  //  throw new java.lang.UnsupportedOperationException("Method valueChanged() not yet implemented.");
    String node=jTree1.getLastSelectedPathComponent().toString();
      if(node.equals("���ÿ�����ϵͳ")){
        jSplitPane1.remove(jSplitPane1.getRightComponent());
        jSplitPane1.add(helloPanel1,JSplitPane.RIGHT);

      }
      if(node.equals("�쿨")){
    jSplitPane1.remove(jSplitPane1.getRightComponent());
    jSplitPane1.add(helloPanel1,JSplitPane.RIGHT);
    }
    if(node.equals("�ⵣ���쿨")){
     jSplitPane1.remove(jSplitPane1.getRightComponent());
     jSplitPane1.add(helloPanel1,JSplitPane.RIGHT);
    }
    if(node.equals("��֤�����쿨")){
      jSplitPane1.remove(jSplitPane1.getRightComponent());
      jSplitPane1.add(WarrantorCheck1,JSplitPane.RIGHT);
     }
     if(node.equals("����Ѻ�쿨")){
       jSplitPane1.remove(jSplitPane1.getRightComponent());
       jSplitPane1.add(ZdthingPanel1,JSplitPane.RIGHT);
      }
      if(node.equals("����Ѻ����")){
     jSplitPane1.remove(jSplitPane1.getRightComponent());
     jSplitPane1.add(ZdthingPanel1,JSplitPane.RIGHT);
    }
    if(node.equals("�쿨����������׼�޸�")){
 jSplitPane1.remove(jSplitPane1.getRightComponent());
  jSplitPane1.add(new Panel(),JSplitPane.RIGHT);
}


    if(node.equals("���õ���")){
    jSplitPane1.remove(jSplitPane1.getRightComponent());
    jSplitPane1.add(helloPanel1,JSplitPane.RIGHT);
    }
    if(node.equals("�����޸�")){
     jSplitPane1.remove(jSplitPane1.getRightComponent());
     jSplitPane1.add(helloPanel1,JSplitPane.RIGHT);
    }

     if(node.equals("�ⵣ���������")){
        jSplitPane1.remove(jSplitPane1.getRightComponent());
        jSplitPane1.add(FreeHalfAdjust1,JSplitPane.RIGHT);
      }
      if(node.equals("����֪ͨ")){
        jSplitPane1.remove(jSplitPane1.getRightComponent());
        jSplitPane1.add( sen,JSplitPane.RIGHT);
      }

      if(node.equals("�ⵣ������")){
      jSplitPane1.remove(jSplitPane1.getRightComponent());
      jSplitPane1.add(testPanel1,JSplitPane.RIGHT);
    }
    if(node.equals("�����޸�")){
      jSplitPane1.remove(jSplitPane1.getRightComponent());
      jSplitPane1.add(yhpasswordPanel1,JSplitPane.RIGHT);
    }

    if(node.equals("�����Ч��")){
      jSplitPane1.remove(jSplitPane1.getRightComponent());
      jSplitPane1.add(FreeValidityCheckPanel1,JSplitPane.RIGHT);
    }
    if(node.equals("Ȩ������")){
   jSplitPane1.remove(jSplitPane1.getRightComponent());
   jSplitPane1.add(SetPriority1,JSplitPane.RIGHT);
   }
   if(node.equals("����Ѻ��ʱ����")){
    jSplitPane1.remove(jSplitPane1.getRightComponent());
    jSplitPane1.add(s12Panel1,JSplitPane.RIGHT);
    }
    if(node.equals("�������ֱ�׼�޸�")){
       jSplitPane1.remove(jSplitPane1.getRightComponent());
       jSplitPane1.add(CreditAdjustSetPanel1,JSplitPane.RIGHT);
       }
    if(node.equals("��֤������ʱ����")){
              jSplitPane1.remove(jSplitPane1.getRightComponent());
              jSplitPane1.add(GuaranteeBetimesAdjust1,JSplitPane.RIGHT);
        }
        if(node.equals("�˳�ϵͳ")){
          ExitSystem1.setBounds(250,200,350,145);
          ExitSystem1.show();
      }



     /*
       if(node.equals("ѧ���γ̹���")){
        jSplitPane1.remove(jSplitPane1.getRightComponent());
        jSplitPane1.add(coursePanel1,JSplitPane.RIGHT);
      }
      if(node.equals("ѧ���ɼ�����")){
        jSplitPane1.remove(jSplitPane1.getRightComponent());
        jSplitPane1.add(scorePanel1,JSplitPane.RIGHT);
      }
      if(node.equals("��ѯ����")){
     jSplitPane1.remove(jSplitPane1.getRightComponent());
     jSplitPane1.add(searchPanel1,JSplitPane.RIGHT);
   }
     if(node.equals("ͳ�ƴ���")){
      jSplitPane1.remove(jSplitPane1.getRightComponent());
      jSplitPane1.add(statisticPanel1,JSplitPane.RIGHT);
      }
  */

  }
}
