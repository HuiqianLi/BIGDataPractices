package management;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

import com.borland.jbcl.layout.*;
import java.sql.*;
import com.borland.dx.dataset.*;
import com.borland.dx.sql.dataset.*;
import com.borland.dbswing.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class GuaranteeBetimesAdjust extends JPanel {
  JLabel jLabel1 = new JLabel();
  JTextField txtinfo1 = new JTextField();
  JButton cmdfind = new JButton();
  JLabel jLabel2 = new JLabel();
  JLabel labshow1 = new JLabel();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JLabel jLabel3 = new JLabel();
  JTextField txtinfo2 = new JTextField();
  JButton cmdchange = new JButton();
  JLabel jLabel4 = new JLabel();
  JLabel labshow3 = new JLabel();
  TitledBorder titledBorder3;
  TitledBorder titledBorder4;

  PreparedStatement pstmt1;
  PreparedStatement pstmt11;
  PreparedStatement pstmt2;
  PreparedStatement pstmt22;
  PreparedStatement sqlcheck;
  Connection con;
  String query1;
  String query2;
  String query11;
  String query22;
  ResultSet rs1;
  ResultSet rs11;
  ResultSet sqlrs;
  String str1;

  String gradechange;
  String money;
  JButton cmdcancel = new JButton();
  JLabel jLabel5 = new JLabel();
  JLabel labshow2 = new JLabel();
  TitledBorder titledBorder5;
  TitledBorder titledBorder6;
  JLabel jLabel6 = new JLabel();
  GridBagLayout gridBagLayout1 = new GridBagLayout();


  public GuaranteeBetimesAdjust() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  void jbInit() throws Exception {
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    titledBorder4 = new TitledBorder("");
    titledBorder5 = new TitledBorder("");
    titledBorder6 = new TitledBorder("");
    jLabel1.setFont(new java.awt.Font("Dialog", 0, 13));
    jLabel1.setText("�������µ����˺ţ�");
    this.setLayout(gridBagLayout1);
    txtinfo1.setFont(new java.awt.Font("Dialog", 0, 13));
    txtinfo1.setText("");
    cmdfind.setBackground(new Color(151, 164, 203));
    cmdfind.setFont(new java.awt.Font("Dialog", 0, 13));
    cmdfind.setText("��ѯ");
    cmdfind.addActionListener(new GuaranteeBetimesAdjust_cmdfind_actionAdapter(this));
    jLabel2.setFont(new java.awt.Font("Dialog", 0, 13));
    jLabel2.setText("�µ��������õȼ���");
    labshow1.setFont(new java.awt.Font("Dialog", 1, 15));
    labshow1.setBorder(titledBorder2);
    labshow1.setText("");
    jLabel3.setFont(new java.awt.Font("Dialog", 0, 13));
    jLabel3.setText("�����������˺ţ�");
    txtinfo2.setBackground(SystemColor.controlLtHighlight);
    txtinfo2.setEnabled(true);
    txtinfo2.setFont(new java.awt.Font("Dialog", 0, 13));
    txtinfo2.setDoubleBuffered(false);
    txtinfo2.setEditable(false);
    txtinfo2.setText("");
    cmdchange.setBackground(new Color(151, 164, 203));
    cmdchange.setEnabled(false);
    cmdchange.setFont(new java.awt.Font("Dialog", 0, 13));
    cmdchange.setText("�޸�");
    cmdchange.addActionListener(new GuaranteeBetimesAdjust_cmdchange_actionAdapter(this));
    jLabel4.setFont(new java.awt.Font("Dialog", 0, 13));
    jLabel4.setText("�������޸ĺ����õȼ���");
    labshow3.setFont(new java.awt.Font("Dialog", 1, 15));
    labshow3.setBorder(titledBorder4);
    labshow3.setText("");
    cmdcancel.setBackground(new Color(151, 164, 203));
    cmdcancel.setFont(new java.awt.Font("Dialog", 0, 13));
    cmdcancel.setText("ȡ��");
    cmdcancel.addActionListener(new GuaranteeBetimesAdjust_cmdcancel_actionAdapter(this));
    jLabel5.setFont(new java.awt.Font("Dialog", 0, 13));
    jLabel5.setText("�����˸��ĺ�Ŀ�͸֧�");
    labshow2.setFont(new java.awt.Font("Dialog", 0, 13));
    labshow2.setBorder(titledBorder6);
    labshow2.setText("");
    jLabel6.setFont(new java.awt.Font("Dialog", 1, 20));
    jLabel6.setText("��֤������ʱ����");
    this.setBackground(new Color(217, 230, 236));
    this.add(jLabel1,  new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(16, 40, 0, 0), 8, 9));
    this.add(jLabel3,  new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(15, 40, 0, 0), 18, 12));
    this.add(jLabel4,  new GridBagConstraints(0, 4, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(19, 40, 0, 7), 10, 11));
    this.add(jLabel2,  new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(18, 40, 0, 18), 25, 11));
    this.add(cmdcancel,  new GridBagConstraints(3, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(21, 15, 54, 41), 12, -4));
    this.add(cmdchange,  new GridBagConstraints(3, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(19, 16, 0, 41), 12, -4));
    this.add(cmdfind,  new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(17, 15, 0, 41), 12, -4));
    this.add(txtinfo1,  new GridBagConstraints(1, 1, 2, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(17, 0, 0, 0), 116, 1));
    this.add(txtinfo2,  new GridBagConstraints(1, 3, 2, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(16, 6, 0, 0), 110, 3));
    this.add(labshow1,  new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(17, 42, 0, 0), 32, 17));
    this.add(labshow3,  new GridBagConstraints(2, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(21, 42, 0, 0), 33, 17));
    this.add(jLabel5,  new GridBagConstraints(0, 5, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(13, 40, 54, 0), 4, 14));
    this.add(labshow2,  new GridBagConstraints(2, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(17, 0, 54, 0), 72, 16));
    this.add(jLabel6,  new GridBagConstraints(0, 0, 4, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(10, 137, 0, 97), 13, 6));
    Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver").newInstance();
  }

  void cmdfind_actionPerformed(ActionEvent e) {
    try {
      String url ="jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
      String username = "sa";
      String password = "";
      con = DriverManager.getConnection(url, username, password);

      //��ѯ�µ��������õȼ����ʸ�
      query1 ="select CreditcardGrade from Creditcard where UserID=?";
      query11 ="select DbrUserID from Users where DbrUserID=?";
      pstmt1 = con.prepareStatement(query1);
      pstmt11 = con.prepareStatement(query11);
      String str1=(txtinfo1.getText()).trim();
      pstmt1.setString(1, str1);
      pstmt11.setString(1, str1);
      rs1 = pstmt1.executeQuery();
      rs11 = pstmt11.executeQuery();

      if(txtinfo1.getText().length()==0){
        txtinfo1.setText("");
        txtinfo2.setText("");
        labshow1.setText("");
        labshow2.setText("");
        labshow3.setText("");
        cmdchange.setEnabled(false);
        txtinfo2.setEditable(false);

        JOptionPane.showMessageDialog(this,"�����뵣���˺ţ�","ȷ����Ϣ",JOptionPane.YES_OPTION);


      }
      else {
      if(rs1.next()){
        if(rs11.next()){
            labshow1.setText(rs1.getString("CreditcardGrade"));
            cmdchange.setEnabled(false);
            txtinfo2.setEditable(false);

            txtinfo2.setText("");
            labshow2.setText("");
            labshow3.setText("");

            JOptionPane.showMessageDialog(this, "�µ�������Ϊ���˵����������ٴ����룡", "ȷ����Ϣ",
                                          JOptionPane.YES_OPTION);

          }

        else {

            labshow1.setText(rs1.getString("CreditcardGrade"));
            String grade = rs1.getString("CreditcardGrade");

            if (grade.equals("A")) {
              gradechange = "B";
              money = "40000Ԫ";
              txtinfo2.setText("");
              labshow2.setText("");
              labshow3.setText("");

              cmdchange.setEnabled(true);
              txtinfo2.setEditable(true);
              cmdfind.setEnabled(false);
              txtinfo1.setEditable(false);

//              JOptionPane.showMessageDialog(this,"�����ô��û���Ϊ�����˵ĵ����ˡ�","ȷ����Ϣ",JOptionPane.YES_OPTION);
            }
            else if (grade.equals("B")) {
              gradechange = "C";
              money = "30000Ԫ";
              txtinfo2.setText("");
              labshow2.setText("");
              labshow3.setText("");

              cmdchange.setEnabled(true);
              txtinfo2.setEditable(true);
              cmdfind.setEnabled(false);
              txtinfo1.setEditable(false);
//              JOptionPane.showMessageDialog(this,"�����ô��û���Ϊ�����˵ĵ����ˡ�","ȷ����Ϣ",JOptionPane.YES_OPTION);
            }
            else if (grade.equals("C")) {
              gradechange = "D";
              money = "20000Ԫ";
              txtinfo2.setText("");
              labshow2.setText("");
              labshow3.setText("");

              cmdchange.setEnabled(true);
              txtinfo2.setEditable(true);
              cmdfind.setEnabled(false);
              txtinfo1.setEditable(false);
//              JOptionPane.showMessageDialog(this,"�����ô��û���Ϊ�����˵ĵ����ˡ�","ȷ����Ϣ",JOptionPane.YES_OPTION);
            }
            else if (grade.equals("D")) {
              gradechange = "E";
              money = "10000Ԫ";
              txtinfo2.setText("");
              labshow2.setText("");
              labshow3.setText("");

              cmdchange.setEnabled(true);
              txtinfo2.setEditable(true);
              cmdfind.setEnabled(false);
              txtinfo1.setEditable(false);
 //             JOptionPane.showMessageDialog(this,"�����ô��û���Ϊ�����˵ĵ����ˡ�","ȷ����Ϣ",JOptionPane.YES_OPTION);
            }
            else if (grade.equals("E")) {
              gradechange = "F";
              money = "5000Ԫ";
              txtinfo2.setText("");
              labshow2.setText("");
              labshow3.setText("");

              cmdchange.setEnabled(true);
              txtinfo2.setEditable(true);
              cmdfind.setEnabled(false);
              txtinfo1.setEditable(false);
 //             JOptionPane.showMessageDialog(this,"�����ô��û���Ϊ�����˵ĵ����ˡ�","ȷ����Ϣ",JOptionPane.YES_OPTION);
            }
            else if (grade.equals("F")) {
              gradechange = "G";
              money = "2000Ԫ";
              txtinfo2.setText("");
              labshow2.setText("");
              labshow3.setText("");

              cmdchange.setEnabled(true);
              txtinfo2.setEditable(true);
              cmdfind.setEnabled(false);
              txtinfo1.setEditable(false);
//              JOptionPane.showMessageDialog(this,"�����ô��û���Ϊ�����˵ĵ����ˡ�","ȷ����Ϣ",JOptionPane.YES_OPTION);
            }
            else if (grade.equals("G")) {
              txtinfo2.setText("");
              labshow2.setText("");
              labshow3.setText("");

              cmdchange.setEnabled(false);
              txtinfo2.setEditable(false);
              JOptionPane.showMessageDialog(this,"���û����õȼ����������ܳ�Ϊ�����˵ĵ����ˡ�","ȷ����Ϣ",JOptionPane.YES_OPTION);
            }
            else if (grade.equals("H")) {
              txtinfo2.setText("");
              labshow2.setText("");
              labshow3.setText("");

              cmdchange.setEnabled(false);
              txtinfo2.setEditable(false);
              JOptionPane.showMessageDialog(this,"���û����õȼ����������ܳ�Ϊ�����˵ĵ����ˡ�","ȷ����Ϣ",JOptionPane.YES_OPTION);
            }
          }
      }
      else{
        txtinfo1.setText("");
        txtinfo2.setText("");
        labshow1.setText("");
        labshow2.setText("");
        labshow3.setText("");
        cmdchange.setEnabled(false);
        txtinfo2.setEditable(false);

        JOptionPane.showMessageDialog(this,"�޴��û���","ȷ����Ϣ",JOptionPane.YES_OPTION);


        }
      }
    }
    catch(Exception em)
    {
       JOptionPane.showMessageDialog(this,"ϵͳ�������������У�","ȷ����Ϣ",JOptionPane.YES_OPTION);
    }

  }

  void cmdchange_actionPerformed(ActionEvent e) {
//�޸������˵ȼ�

try {
      String url =
          "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
      String username = "sa";
      String password = "";
      con = DriverManager.getConnection(url, username, password);

      if (txtinfo2.getText().length() == 0) {
       JOptionPane.showMessageDialog(this,"�����������˺ţ�","ȷ����Ϣ",JOptionPane.YES_OPTION);
      }
      else {
        String sql = "select UserID from Users where UserID=?";
        sqlcheck = con.prepareStatement(sql);
        String check = (txtinfo2.getText()).trim();
        sqlcheck.setString(1, check);
        sqlrs = sqlcheck.executeQuery();
        if (sqlrs.next()) {
          query2 = "update Users set DbrUserID=? where UserID=?";
          pstmt2 = con.prepareStatement(query2);
          String str2 = (txtinfo2.getText()).trim();
          String str1 = (txtinfo1.getText()).trim();
          pstmt2.setString(1, str1);
          pstmt2.setString(2, str2);
          pstmt2.executeUpdate();

          query22 = "update Creditcard set CreditcardGrade=? where UserID=?";
          pstmt22 = con.prepareStatement(query22);
          pstmt22.setString(1, gradechange);
          pstmt22.setString(2, str2);
          pstmt22.executeUpdate();

          labshow3.setText(gradechange);
          labshow2.setText(money);
          cmdchange.setEnabled(false);
          txtinfo2.setEditable(false);
          cmdfind.setEnabled(true);
          txtinfo1.setEditable(true);

          JOptionPane.showMessageDialog(this, "���ĳɹ���", "ȷ����Ϣ",
                                        JOptionPane.INFORMATION_MESSAGE);
        }
        else{
          txtinfo2.setText("");
          JOptionPane.showMessageDialog(this, "�޴��û���", "ȷ����Ϣ",JOptionPane.YES_OPTION);
        }
      }
    }
    catch(Exception em)
       {
         JOptionPane.showMessageDialog(this,"ϵͳ�������������У�","ȷ����Ϣ",JOptionPane.YES_OPTION);
       }

  }

  void cmdcancel_actionPerformed(ActionEvent e) {
    txtinfo1.setText("");
    txtinfo2.setText("");
    labshow1.setText("");
    labshow2.setText("");
    labshow3.setText("");
    cmdchange.setEnabled(false);
    txtinfo2.setEditable(false);
    cmdfind.setEnabled(true);
    txtinfo1.setEditable(true);

    eventFrame.jSplitPane1.remove(eventFrame.jSplitPane1.getRightComponent());
    eventFrame.jSplitPane1.add(new helloPanel(),JSplitPane.RIGHT);
  }

}

class GuaranteeBetimesAdjust_cmdfind_actionAdapter implements java.awt.event.ActionListener {
  GuaranteeBetimesAdjust adaptee;

  GuaranteeBetimesAdjust_cmdfind_actionAdapter(GuaranteeBetimesAdjust adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.cmdfind_actionPerformed(e);
  }
}

class GuaranteeBetimesAdjust_cmdchange_actionAdapter implements java.awt.event.ActionListener {
  GuaranteeBetimesAdjust adaptee;

  GuaranteeBetimesAdjust_cmdchange_actionAdapter(GuaranteeBetimesAdjust adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.cmdchange_actionPerformed(e);
  }
}

class GuaranteeBetimesAdjust_cmdcancel_actionAdapter implements java.awt.event.ActionListener {
  GuaranteeBetimesAdjust adaptee;

  GuaranteeBetimesAdjust_cmdcancel_actionAdapter(GuaranteeBetimesAdjust adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.cmdcancel_actionPerformed(e);
  }
}
