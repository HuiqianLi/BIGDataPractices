package management;

import java.awt.*;
import javax.swing.*;
import com.borland.dx.sql.dataset.*;
import com.borland.dbswing.*;
import com.borland.dx.dataset.*;
import java.awt.event.*;
import java.sql.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class FreeValidityCheckPanel extends JPanel {
  JLabel jLabel2 = new JLabel();
  JTextField jTextField2 = new JTextField();
  TableScrollPane tableScrollPane1 = new TableScrollPane();
  JdbTable jdbTable1 = new JdbTable();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  Database database1 = new Database();
  QueryDataSet queryDataSet1 = new QueryDataSet();
  QueryResolver queryResolver1 = new QueryResolver();
  DBDisposeMonitor dBDisposeMonitor1 = new DBDisposeMonitor();
  Column column1 = new Column();
  Column column2 = new Column();
  Column column3 = new Column();
  Column column4 = new Column();
  Column column5 = new Column();
  PreparedStatement pstmt;
  Connection con;
  String query;
  String query1;
  ResultSet rs;
  String str;
  messDialogx messDialogx1;
  messaDialog messaDialog1;
  JLabel jLabel1 = new JLabel();
  JTextField jTextField1 = new JTextField();

  rejectDialog rejectDialog1;
  JbxxDialog JbxxDialog1;
  String YHworkerID;

  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  public FreeValidityCheckPanel() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public FreeValidityCheckPanel(String str) {
    YHworkerID=str;
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }


  void jbInit() throws Exception {
    this.setLayout(gridBagLayout1);
    jLabel2.setFont(new java.awt.Font("����", 1, 22));
    jLabel2.setText("����֤�ţ�");
    jTextField2.setText("");
    jButton3.setBackground(new Color(151, 164, 203));
    jButton3.setEnabled(true);
    jButton3.setText("ȷ��");
    //jButton3.setEnabled(true);
    jButton3.addActionListener(new
FreeValidityCheckPanel_jButton3_actionAdapter(this));
    jButton4.setBackground(new Color(151, 164, 203));
    jButton4.setEnabled(true);
    jButton4.setText("����");
    jButton4.addActionListener(new
FreeValidityCheckPanel_jButton4_actionAdapter(this));
    database1.setConnection(new
com.borland.dx.sql.dataset.ConnectionDescriptor("jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES", "sa", "", false, "com.microsoft.jdbc.sqlserver.SQLServerDriver"));

database1.setTransactionIsolation(java.sql.Connection.TRANSACTION_READ_COMMITTED);
    database1.setDatabaseName("");
    queryDataSet1.setEditable(true);
    queryDataSet1.setResolver(queryResolver1);
   // queryDataSet1.setQuery(new com.borland.dx.sql.dataset.QueryDescriptor(database1, "select BadRecdId,UnOverdraft,BadRecord,CriminalRecord,OtherDebt from view1 where usercard='510211186209161213'", null, true, Load.ALL));

    queryResolver1.setDatabase(database1);

queryResolver1.setUpdateMode(com.borland.dx.dataset.UpdateMode.KEY_COLUMNS);
    jdbTable1.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
    jdbTable1.setDataSet(queryDataSet1);
    column1.setCaption("���");
    column1.setColumnName("BadRecdId");
    column1.setDataType(com.borland.dx.dataset.Variant.STRING);
    column1.setPrecision(20);
    column1.setRowId(true);
    column1.setTableName("Badrecord");
    column1.setServerColumnName("BadRecdId");
    column1.setSqlType(12);
    column2.setCaption("������͸֧����");
    column2.setColumnName("UnOverdraft");
    column2.setDataType(com.borland.dx.dataset.Variant.STRING);
    column2.setPrecision(40);
    column2.setTableName("Badrecord");
    column2.setServerColumnName("UnOverdraft");
    column2.setSqlType(12);
    column3.setCaption("���в�����¼����");
    column3.setColumnName("BadRecord");
    column3.setDataType(com.borland.dx.dataset.Variant.STRING);
    column3.setPrecision(40);
    column3.setTableName("Badrecord");
    column3.setServerColumnName("BadRecord");
    column3.setSqlType(12);
    column4.setCaption("���¼�¼");
    column4.setColumnName("CriminalRecord");
    column4.setDataType(com.borland.dx.dataset.Variant.STRING);
    column4.setPrecision(40);
    column4.setTableName("Badrecord");
    column4.setServerColumnName("CriminalRecord");
    column4.setSqlType(12);
    column5.setCaption("����δ��ծ��");
    column5.setColumnName("OtherDebt");
    column5.setDataType(com.borland.dx.dataset.Variant.STRING);
    column5.setPrecision(40);
    column5.setTableName("Badrecord");
    column5.setServerColumnName("OtherDebt");
    column5.setSqlType(12);
    queryDataSet1.setColumns(new Column[] {column1, column2, column3,
column4, column5});
    jLabel1.setFont(new java.awt.Font("����", 1, 22));
    jLabel1.setText("�û�������");
    jTextField1.setText("");

    jButton1.setBackground(new Color(151, 164, 203));
    jButton1.setEnabled(false);
    jButton1.setText("ͨ�����");
    jButton1.addActionListener(new FreeValidityCheckPanel_jButton1_actionAdapter(this));
    jButton2.setBackground(new Color(151, 164, 203));
    jButton2.setEnabled(false);
    jButton2.setText("��������");
    jButton2.addActionListener(new FreeValidityCheckPanel_jButton2_actionAdapter(this));
    this.setBackground(new Color(217, 230, 236));
    tableScrollPane1.getViewport().setBackground(new Color(217, 230, 236));
    this.add(tableScrollPane1,  new GridBagConstraints(0, 3, 4, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(17, 3, 0, 3), -9, -292));
    this.add(jButton4,  new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(10, 34, 0, 132), 18, 1));
    this.add(jButton3,  new GridBagConstraints(0, 2, 3, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(11, 129, 0, 26), 16, 0));
    this.add(jTextField1,  new GridBagConstraints(2, 0, 2, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(21, 0, 0, 78), 217, -1));
    this.add(jTextField2,  new GridBagConstraints(2, 1, 2, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(14, 0, 0, 78), 218, -1));
    this.add(jLabel2,  new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(11, 26, 0, 0), 7, 3));
    this.add(jLabel1,  new GridBagConstraints(0, 0, 2, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(21, 28, 0, 0), 25, -3));
    this.add(jButton2,  new GridBagConstraints(3, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(10, 49, 17, 111), 2, 1));
    this.add(jButton1,  new GridBagConstraints(1, 4, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(9, 0, 17, 0), 5, 2));
    tableScrollPane1.getViewport().add(jdbTable1, null);
    messDialogx1=new messDialogx();
    messaDialog1=new messaDialog();
    Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
    String url = "jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=CCES";
    String username= "sa";
    String password= "";
    con = DriverManager.getConnection(url,username,password);
    query="select * from users where usercard=?";
    pstmt = con.prepareStatement(query);
  }

  void jButton3_actionPerformed(ActionEvent e) {
   try{
     str=jTextField2.getText();

     pstmt = con.prepareStatement(query);
     pstmt.setString(1,str);
     rs = pstmt.executeQuery();
    if(rs.next()){
      pstmt.close();
      query1 = "select * from view1 where usercard=?";
      pstmt = con.prepareStatement(query1);
      pstmt.setString(1, str);
      rs = pstmt.executeQuery();
      if (rs.next()) {
        jButton2.setEnabled(true);
        jButton1.setEnabled(false);
        queryDataSet1.close();
        str = rs.getString("usercard");
        queryDataSet1.setQuery(new com.borland.dx.sql.dataset.QueryDescriptor(
            database1,
            "select BadRecdId,UnOverdraft,BadRecord,CriminalRecord,OtherDebt from view1 where usercard=" + "\'" +
            str + "\'", null, true, Load.ALL));
        queryDataSet1.refresh();
        jdbTable1.setDataSet(queryDataSet1);
        jdbTable1.repaint();

      }
      else {
        jButton1.setEnabled(true);
        jButton2.setEnabled(false);
       // jTextField1.setText("û�в�����¼!");
        messaDialog1.setBounds(270,140,130,125);
        messaDialog1.show();
        jdbTable1.setDataSet(null);
        jdbTable1.repaint();

      }
    }
    else
      { messDialogx1.setBounds(270,140,130,125);
        messDialogx1.show();
        jButton1.setEnabled(true);
        jButton2.setEnabled(false);
        queryDataSet1.close();
       queryDataSet1.refresh();
       jdbTable1.setDataSet(null);
       jdbTable1.repaint();
      }
     }
     catch(Exception ef)
     { System.out.print("ϵͳ�������������С�"+ef.getClass().getName());
       ef.printStackTrace();
     }
  }

  void jButton4_actionPerformed(ActionEvent e) {
    jTextField2.setText("");
    jTextField1.setText("");
    jdbTable1.setDataSet(null);
    jdbTable1.repaint();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    rejectDialog1=new rejectDialog(jTextField1.getText(),jTextField2.getText());
    rejectDialog1.setBounds(200,150,340,320);
    rejectDialog1.show();
  }

  void jButton1_actionPerformed(ActionEvent e) {
      JbxxDialog1=new JbxxDialog (jTextField1.getText(),jTextField2.getText(),YHworkerID,9);
      JbxxDialog1.setBounds(200,50,500,400);
      JbxxDialog1.show();
  }
}

class FreeValidityCheckPanel_jButton3_actionAdapter implements
java.awt.event.ActionListener {
  FreeValidityCheckPanel adaptee;

  FreeValidityCheckPanel_jButton3_actionAdapter(FreeValidityCheckPanel
adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class FreeValidityCheckPanel_jButton4_actionAdapter implements
java.awt.event.ActionListener {
  FreeValidityCheckPanel adaptee;

  FreeValidityCheckPanel_jButton4_actionAdapter(FreeValidityCheckPanel
adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton4_actionPerformed(e);
  }
}

class FreeValidityCheckPanel_jButton2_actionAdapter implements java.awt.event.ActionListener {
  FreeValidityCheckPanel adaptee;

  FreeValidityCheckPanel_jButton2_actionAdapter(FreeValidityCheckPanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class FreeValidityCheckPanel_jButton1_actionAdapter implements java.awt.event.ActionListener {
  FreeValidityCheckPanel adaptee;

  FreeValidityCheckPanel_jButton1_actionAdapter(FreeValidityCheckPanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}


