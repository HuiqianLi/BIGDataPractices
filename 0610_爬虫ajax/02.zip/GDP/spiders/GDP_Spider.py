import scrapy
from bs4 import BeautifulSoup
import re
import json
import time
from GDP.items import GdpItem
class GDP_Spider(scrapy.Spider):
    
    name = "GDP_Spider"
    headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36',
            }

    def start_requests(self):
        url = 'http://data.stats.gov.cn/search.htm?s=GDP&m=searchdata&db=&p=0'
        yield scrapy.Request(url, headers = self.headers)

    def parse(self, response):
        datas = json.loads(response.body)
        results = datas['result']
        current_page = datas['pagecurrent']
        page_count = datas['pagecount']
        print(current_page)
        data_list = {
            '数值': [],
            '所属栏目': [],
            '地区':[],
            '数据时间':[],
            '指标':[]
        }
        
        for res in results:
            data_list['数值'].append(res['data'])
            data_list['所属栏目'].append(res['db'])
            data_list['地区'].append(res['reg'])
            data_list['数据时间'].append(res['sj'])
            data_list['指标'].append(res['zb'])
        # yield item
        item = GdpItem(data=data_list['数值'], db=data_list['所属栏目'],
                             region=data_list['地区'], time=data_list['数据时间'],
                             index=data_list['指标'])
        yield item
        if current_page < page_count:
            time.sleep(1)
            current_page += 1
            next_url = 'http://data.stats.gov.cn/search.htm?s=GDP&m=searchdata&db=&p='+str(current_page)
            yield scrapy.Request(next_url, headers=self.headers)