# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pandas as pd
import time
import os

def get_date():
    localtime = time.localtime(time.time())
    date = str(localtime[0]) + '.' + str(localtime[1]) + '.' + str(localtime[2])
    return date

class GdpPipeline(object):
    def process_item(self, item, spider):
        return item

class CSVPipeline(object):
    def __init__(self):
        self.file_name = get_date() + '.csv'
        self.file_path = os.path.join('data', self.file_name)
    
    def process_item(self, item, spider):
        item_dic = dict(item)
        print(item_dic['data'])
        df = pd.DataFrame({
            '数值':item_dic['data'],
            '所属栏目':item_dic['db'],
            '地区':item_dic['region'],
            '数据时间':item_dic['time'],
            '指标':item_dic['index']
        })
        df.to_csv(self.file_path, index=False, sep=',', encoding='utf_8_sig', mode='a+')