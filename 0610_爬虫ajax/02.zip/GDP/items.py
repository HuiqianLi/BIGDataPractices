# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class GdpItem(scrapy.Item):
    data = scrapy.Field()
    db = scrapy.Field()
    region = scrapy.Field()
    time = scrapy.Field()
    index = scrapy.Field()
