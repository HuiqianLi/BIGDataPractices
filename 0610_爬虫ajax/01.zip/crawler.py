from bs4 import BeautifulSoup
import requests
import time
import pandas as pd
import os

from utils import remove_space, check_ip

class crawler:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
        }
        self.base_url = 'https://www.xicidaili.com/'
        self.postFixes = [
            'nn/',
            'nt/',
            'wn/',
            'wt/'
        ]
    
    def save_as_csv(self, item, proxy_name):
        df = pd.DataFrame({'ip': item['ip'],
                        'port': item['port'],
                        'server_address': item['server_addr'],
                        'anonymous_status': item['anonymous_status'],
                        'protocol': item['protocol'],
                        'connection_speed': item['speed'],
                        'connection_time': item['connection_time'],
                        'alive_time': item['alive_time'],
                        'check_time': item['check_time'],
                        'ip_available': item['ip_available']})
        proxy_dict = {
            'nn/': '国内高匿代理',
            'nt/': '国内普通代理',
            'wn/': '国内HTTPS代理',
            'wt/': '国内HTTP代理'
        }
        file_name = proxy_dict[proxy_name]+'.csv'
        file_path = os.path.join('data', file_name)
        try:
            df.to_csv(file_path, index=False, sep=',', encoding='utf_8_sig', mode='a+')
        except:
            print('SAVE ERROR: please close csv')
    
    def crawl(self):
        for postFix in self.postFixes:
            target_url = self.base_url + postFix
            hTarget = requests.get(target_url, headers=self.headers)
            soup = BeautifulSoup(hTarget.text, 'lxml')
            # 获取总页码数
            ###########如果使用真实页数，请注意循环时间和使用代理###########
            # for i in range(int(soup.find_all('a')[-3].text)):
            for i in range(1):
                page_url = self.base_url + postFix + str(i+1)
                page_hTarget = requests.get(page_url, headers=self.headers)
                soup = BeautifulSoup(page_hTarget.text, 'lxml')
                trs = soup.find_all("tr")
                ip_list = []
                port_list = []
                server_addr = []
                anonymous_status = []
                protocol_type = []
                speed = []
                connection_time = []
                alive_time = []
                check_time = []
                ip_ava = []
                for tr in trs:
                    tds = tr.select('td')
                    if len(tds) == 0:
                        continue
                    else:
                        ip = remove_space(tds[1].text)
                        ip += ":"+remove_space(tds[2].text)
                        time.sleep(1)
                        tmp = check_ip(ip)
                        print(tmp)
                        ip_ava.append(tmp)
                        ip_list.append(remove_space(tds[1].text))
                        port_list.append(remove_space(tds[2].text))
                        try:
                            server_addr.append(tds[3].select('a')[0].text)
                        except:
                            server_addr.append(remove_space(tds[3].text))
                        anonymous_status.append(remove_space(tds[4].text))
                        protocol_type.append(remove_space(tds[5].text))
                        speed.append(remove_space(tds[6].select('div')[0].get('title')))
                        connection_time.append(remove_space(tds[7].select('div')[0].get('title')))
                        alive_time.append(remove_space(tds[8].text))
                        check_time.append(remove_space(tds[9].text))

                item = {
                    'ip': ip_list,
                    'port': port_list,
                    'server_addr': server_addr,
                    'anonymous_status': anonymous_status,
                    'protocol': protocol_type,
                    'speed': speed,
                    'connection_time': connection_time,
                    'alive_time': alive_time,
                    'check_time': check_time,
                    "ip_available": ip_ava
                }
                self.save_as_csv(item, postFix)