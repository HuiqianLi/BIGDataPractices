from crawler import crawler

if __name__ == "__main__":
    c = crawler()
    c.crawl()