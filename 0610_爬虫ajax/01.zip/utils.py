def remove_space(space_str):
    space_str = space_str.replace("\n","")
    space_str = space_str.replace(" ","")
    return space_str

def check_ip(ip_addr):
    headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36'
        }
    proxies = {
        "http": "http://"+ip_addr,
        "https": "https://"+ip_addr
    }
    # print(proxies["http"])
    try:
        requests.get("https://www.baidu.com", headers=headers, proxies=proxies, timeout=5)
    except:
        return "false"
    return "true"