package com.hwadee.entity;

public class Result {
	/* 鐘舵�佺爜 */
	private int code;
	/* 鎻愮ず淇℃伅 */
	private String message;
	/* 鍥炲啓鐨勬暟鎹� */
	private Object data;

	public Result() {
	}

	public Result(int code) {
		this.code = code;
	}

	public Result(int code, String message) {
		this.code = code;
		this.message = message;
	}

	public Result(int code, String message, Object data) {
		this.code = code;
		this.message = message;
		this.data = data;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "Result{" + "code=" + code + ", message='" + message + '\'' + ", data=" + data + '}';
	}
}
