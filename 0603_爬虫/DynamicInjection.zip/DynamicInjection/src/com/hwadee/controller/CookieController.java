package com.hwadee.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.hwadee.entity.Result;

@WebServlet("/cookies")
public class CookieController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String method = request.getParameter("injMethod");

		switch (method) {
		case "handleCookie":
			response.setHeader("Set-Cookie", "test=python3");
			response.addCookie(new Cookie("word", "python"));
			response.addCookie(new Cookie("date", new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date())));

			response.getWriter().append(JSON.toJSONString(new Result(200, "success", "set cookies OK")));
			break;
		case "getCookie":

			Cookie[] cookies = request.getCookies();

			response.getWriter().append(JSON.toJSONString(new Result(200, "success", cookies)));
			break;
		default:
			break;
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
