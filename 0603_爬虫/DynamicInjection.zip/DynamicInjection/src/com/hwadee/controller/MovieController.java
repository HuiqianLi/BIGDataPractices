package com.hwadee.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.hwadee.entity.Movie;
import com.hwadee.entity.Result;

@WebServlet("/movie")
public class MovieController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	List<Movie> movies = new ArrayList<Movie>();

	public MovieController() {
		super();

		movies.add(new Movie("操控者/A or B", "幕后玩家", "徐峥 Zheng Xu", "汉语", "任鹏远",
				"'https://img.18qweasd.com/d/file/html/gndy/dyzz/2018-05-28/d240111954bb914e4a34b61b23ccf33d.jpg"));
		movies.add(new Movie("我是李雪莲", "我不是潘金莲", "范冰冰", "汉语", "冯小刚",
				"http://tu.23juqing.com/d/file/html/gndy/jddy/2017-01-21/25f4096970881fe51d7f894b9c38a720.jpg"));
		movies.add(new Movie("灾难艺术家", "The Disaster Artist", "詹姆斯·弗兰科 James Franco", "英语", "詹姆斯·弗兰科 James Franco",
				"https://img.18qweasd.com/d/file/html/gndy/dyzz/2018-02-22/ad0788595cde5d33e14c991d4ed671d6.jpg"));
		movies.add(new Movie("黑豹", "Black Panther", "查德维克·博斯曼 Chadwick Boseman", "英语/韩语", "瑞恩·库格勒 Ryan Coogler",
				"https://img.18qweasd.com/d/file/html/gndy/dyzz/2018-05-02/2911955d9487af8140975049b8582d5f.jpg"));
		movies.add(new Movie("神奇动物在哪里", "Fantastic Beasts and Where to Find Them", "埃迪·雷德梅恩 Eddie Redmayne", "英语",
				"大卫·叶茨 David Yates",
				"http://tu.23juqing.com/d/file/html/gndy/dyzz/2017-01-16/0a1a64020602c285bf15a8775043d190.jpg"));
		movies.add(new Movie("南极绝恋", "南极之恋", "赵又廷 Mark Chao", "普通话", "吴有音 Youyin Wu",
				"https://img.18qweasd.com/d/file/html/gndy/dyzz/2018-03-24/c5c2f1081b41a81648cae404515efb4b.jpg"));
		movies.add(new Movie("刀锋·红海行动", "红海行动", "张译 Yi Zhang", "汉语", "林超贤 Dante Lam",
				"https://img.18qweasd.com/d/file/html/gndy/dyzz/2018-04-30/f044658d178a75b644ba073d433880e1.jpg"));
		movies.add(new Movie("毕业风暴", "Bacalaureat", "阿德里安·蒂蒂耶尼", "法语", "克里斯蒂安·蒙吉",
				"http://tu.23juqing.com/d/file/html/gndy/dyzz/2017-05-08/feae1c2d597e0e85f7e7ca7d5c8bc66d.jpg"));
		movies.add(new Movie("三生三世十里桃花", "Once Upon a Time", "刘亦菲", "汉语", "赵小丁/安东尼·拉默里纳拉",
				"http://img.18qweasd.com/d/file/html/gndy/dyzz/2017-09-03/879c8184f1cb49b23b2484ac7ef6f172.jpg"));
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String method = request.getParameter("injMethod");

		Result result;

		switch (method) {
		case "list":
			String value = request.getParameter("value");

			if (value == null || value.length() == 0) {
				result = new Result(200, "success", movies);
			} else {
				List<Movie> list = new ArrayList<Movie>();
				for (Movie movie : movies) {
					if (movie.getMname().contains(value) || movie.getMaliasname().contains(value)
							|| movie.getLeadingactor().contains(value)) {
						list.add(movie);
					}
				}

				result = new Result(200, "success", list);
			}

			response.getWriter().append(JSON.toJSONString(result));
			break;
		case "page":

			break;
		default:
			break;
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
