package com.hwadee.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.hwadee.entity.Result;

@WebServlet("/user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String method = request.getParameter("injMethod");

		switch (method) {
		case "login":
			String username = request.getParameter("username");
			String password = request.getParameter("password");

			if (username != null && password != null && "zhangsan".equals(username) && "123".equals(password)) {
				request.getSession().setAttribute("user", username);
				response.getWriter().append(JSON.toJSONString(new Result(200, "success")));
			} else {
				response.getWriter().append(JSON.toJSONString(new Result(-1, "failure")));
			}

			break;
		default:
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
