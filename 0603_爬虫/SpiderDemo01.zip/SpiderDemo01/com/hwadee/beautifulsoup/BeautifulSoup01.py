from bs4 import BeautifulSoup
import requests

headers = {
    'Connection': 'keep-alive',
    # 模拟浏览器操作
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.142 Safari/537.36'
}
response = requests.get('https://www.xicidaili.com/nn/', headers=headers)

# 构建解析对象，参数1：源数据 HTML 网页源代码；参数2：解析模式
soup = BeautifulSoup(response.text, 'lxml')

# 使用 soup 对象，获取相应标签及数据
# 1.格式化输出
# print(soup.prettify())

# 2.直接取标签，直接子元素标签
# print(soup.meta)

# 3.通过 find 函数获取标签
# 查找所有同名的标签
# trs = soup.find_all('tr')
# print(len(trs))
# print(trs)

# table = soup.find('table', id="ip_list")
# trs = table.find_all('tr')
# print(len(trs))
# print(trs)


# ths = soup.find_all('th', class_="country")
# print(len(ths))
# print(ths)

# 4.通过 CSS 样式查找标签
# print(soup.select('#ip_list > tbody > tr:nth-child(2) > td'))
tds = soup.select('#ip_list > tr:nth-child(2) > td')
print(len(tds))
print(tds)
