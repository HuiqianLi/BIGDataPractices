import requests

response = requests.get('http://www.ecar168.cn/xiaoliang/liebiao/2_0.htm')

# response = requests.get('https://www.baidu.com/s',
#                         params={
#                             'wd': 'book',
#                             'ie': 'utf-8',
#                         }
#                         )

print(response.headers)
print(response.encoding)
response.encoding = 'gbk'
print(response.text)
