import requests

headers = {
    'Connection': 'keep-alive',
    # 模拟浏览器操作
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.142 Safari/537.36'
}

session = requests.session()

response1 = session.get('http://localhost:8080/DynamicInjection/cookies?injMethod=handleCookie', headers=headers)

print('response1.request.headers:', response1.request.headers)
print('response1.cookies:', response1.cookies)

# 后续带 Cookies 的请求
response2 = session.get('http://localhost:8080/DynamicInjection/cookies?injMethod=getCookie')

print('response2.request.headers:', response2.request.headers)
print('response2.cookies:', response2.cookies)

# 后续带 Cookies 的请求
response3 = session.get('http://localhost:8080/DynamicInjection/cookies?injMethod=getCookie')

print('response3.request.headers:', response3.request.headers)
print('response3.cookies:', response3.cookies)
