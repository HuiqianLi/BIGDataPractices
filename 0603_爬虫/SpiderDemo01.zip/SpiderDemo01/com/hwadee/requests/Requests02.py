import requests

headers = {
    'Connection': 'keep-alive',
    # 添加链式请求
    'Referer': 'http://www.ecar168.cn/xiaoliang/liebiao/2_0.htm',
    # 模拟浏览器操作
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.142 Safari/537.36'
}

response = requests.get('http://www.ecar168.cn/xiaoliang/phb_lx/31_2.htm', headers=headers)

print('response.request.headers:', response.request.headers)
print('response.headers:', response.headers)
