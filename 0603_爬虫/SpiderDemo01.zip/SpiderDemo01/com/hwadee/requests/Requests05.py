import requests

headers = {
    'Connection': 'keep-alive',
    # 模拟浏览器操作
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.142 Safari/537.36'
}

proxies = {
    'http': 'http://113.59.99.138:8910',
    # 'https': 'https://123.58.17.134:3128',
}

session = requests.session()
# session.keep_alive = False

response1 = session.get('https://www.cnblogs.com', headers=headers,
                        proxies=proxies)

print('response1.request.headers:', response1.request.headers)
print('response1.headers:', response1.headers)
