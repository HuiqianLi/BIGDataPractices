import requests

headers = {
    'Connection': 'keep-alive',
    # 模拟浏览器操作
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.142 Safari/537.36'
}

response = requests.get('http://localhost:8080/DynamicInjection/cookies?injMethod=handleCookie', headers=headers)

print(response.headers)
print(response.headers['Set-Cookie'])
print(response.cookies)

cookies = response.cookies

# 后续带 Cookies 的请求
requests.get('', cookies=cookies)
