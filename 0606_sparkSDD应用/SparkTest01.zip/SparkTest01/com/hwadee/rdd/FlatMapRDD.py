from pyspark import SparkContext, SparkConf

# 构建 配置对象
conf = SparkConf().setAppName('Parallelize').setMaster('local[*]')
# 构建 环境对象
sc = SparkContext(conf=conf)

originRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\wordcount.txt')
print('originRDD:', originRDD.count())
print('originRDD:', originRDD.collect())


def flatMapFunc(line):
    return str(line).replace(',', ' ').replace('.', ' ').replace('(', ' ').replace(')', ' ').split(' ')


# 使用 RDD  Transformation API 中的 FlatMap 将原始数据进行单词拆分
# originRDD.flatMap(flatMapFunc)
# List<List<String>>/List<String> -(flatMap)-> List<String> :RDD<String>
flatMapRDD = originRDD.flatMap(
    lambda row: str(row).replace(',', ' ').replace('.', ' ').replace('(', ' ').replace(')', ' ').split(' '))
print('flatMapRDD:', flatMapRDD.count())
print('flatMapRDD:', flatMapRDD.collect())

# originRDD.flatMap(lambda row: len(row))
