from pyspark import SparkContext, SparkConf

conf = SparkConf().setAppName('Parallelize').setMaster('local[*]')
sc = SparkContext(conf=conf)

originRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\wordcount.txt')

# 1、计算总的字符数或者说文档总长度
# lenRDD = originRDD.map(lambda row: len(row))
# print(lenRDD.collect())
# print('SUM:', lenRDD.reduce(lambda a, b: a + b))

# 2、计算单词出现的频率
flatMapRDD = originRDD.flatMap(
    lambda row: str(row).replace(',', ' ').replace('.', ' ').replace('(', ' ').replace(')', ' ').split(' '))

print(flatMapRDD.take(10))

mapRDD = flatMapRDD.map(lambda word: (word, 1))

print(mapRDD.take(10))

reduceByKeyRDD = mapRDD.reduceByKey(lambda a, b: a + b)

print(reduceByKeyRDD.collect())
