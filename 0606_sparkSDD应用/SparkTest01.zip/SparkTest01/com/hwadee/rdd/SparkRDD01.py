from pyspark import SparkContext, SparkConf

# 构建 配置对象
conf = SparkConf().setAppName('SparkRDD01').setMaster('local[*]')
# 构建 环境对象
sc = SparkContext(conf=conf)

print(sc)
