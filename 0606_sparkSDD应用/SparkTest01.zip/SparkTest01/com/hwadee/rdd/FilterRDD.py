from pyspark import SparkContext, SparkConf

conf = SparkConf().setAppName('Parallelize').setMaster('local[*]')
sc = SparkContext(conf=conf)

originRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\wordcount.txt')

# 2、计算单词出现的频率
flatMapRDD = originRDD.flatMap(
    lambda row: str(row).replace(',', ' ').replace('.', ' ').replace('(', ' ').replace(')', ' ').split(' '))

filterRDD = flatMapRDD.filter(lambda word: len(word) > 3)

print(filterRDD.map(lambda word: (word, 1)).reduceByKey(lambda a, b: a + b).collect())
