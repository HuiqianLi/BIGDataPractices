from pyspark import SparkContext, SparkConf

conf = SparkConf().setAppName('Parallelize').setMaster('local[*]')
sc = SparkContext(conf=conf)

originRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\wordcount.txt')

# 2、计算单词出现的频率
flatMapRDD = originRDD.flatMap(
    lambda row: str(row).replace(',', ' ').replace('.', ' ').replace('(', ' ').replace(')', ' ').split(' '))
mapRDD = flatMapRDD.filter(lambda word: len(word) > 0).map(lambda word: (word, 1))
reduceByKeyRDD = mapRDD.reduceByKey(lambda a, b: a + b)

sortByKeyRDD = reduceByKeyRDD.map(lambda tuple: (tuple[1], tuple[0])) \
    .sortByKey(ascending=False) \
    .map(lambda tuple: (tuple[1], tuple[0]))
print(sortByKeyRDD.take(10))
