from pyspark import SparkContext, SparkConf

# 构建 配置对象
conf = SparkConf().setAppName('Parallelize').setMaster('local[*]')
# 构建 环境对象
sc = SparkContext(conf=conf)

data = [1, 2, 3, 4, 5]
df = sc.parallelize(data)

list = df.collect()

print(list)
