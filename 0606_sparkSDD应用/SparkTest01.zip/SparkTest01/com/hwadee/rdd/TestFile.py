from pyspark import SparkContext, SparkConf

# 构建 配置对象
conf = SparkConf().setAppName('TestFile').setMaster('local[*]')
# 构建 环境对象
sc = SparkContext(conf=conf)

# 从文件中获取结构化数据（hdfs、local、file（txt/csv))
originRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\20190315.csv')
# hdfs
# hdfsRDD = sc.textFile('hdfs://172.20.1.1:9000/123.txt')

print('originRdd.count():', originRDD.count())

print('originRdd.take(2):', originRDD.take(2))

for item in originRDD.collect():
    print('item:', item)
