from pyspark import SparkContext, SparkConf

conf = SparkConf().setAppName('GT9000.py').setMaster('local[*]')
sc = SparkContext(conf=conf)

originTMRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\tianmao.txt')

filterTMRDD = originTMRDD.filter(lambda row: int(str(row).split('\t')[2]) > 9000)

resultTMRDD = filterTMRDD.map(lambda row: str(row).split('\t')[0])

print('天猫中销量大于9000的商品id:', resultTMRDD.collect())

originJDRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\jd.txt')

filterJDRDD = originJDRDD.filter(lambda row: int(str(row).split('\t')[2]) > 9000)

resultJDRDD = filterJDRDD.map(lambda row: str(row).split('\t')[0])

print('京东中销量大于9000的商品id:', resultJDRDD.collect())

print('销量大于9000的商品id:', resultTMRDD.union(resultJDRDD).distinct().collect())
