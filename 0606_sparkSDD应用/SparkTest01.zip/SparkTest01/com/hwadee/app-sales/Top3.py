from pyspark import SparkContext, SparkConf

conf = SparkConf().setAppName('Top3.py').setMaster('local[*]')
sc = SparkContext(conf=conf)

originTMRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\tianmao.txt')

mapRDD = originTMRDD.map(lambda row: str(row).split('\t'))
# print(mapRDD.collect())

print(mapRDD.sortBy(lambda row: row[2], ascending=False).take(3))
