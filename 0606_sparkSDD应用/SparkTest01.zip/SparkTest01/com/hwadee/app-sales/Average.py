from pyspark import SparkContext, SparkConf

conf = SparkConf().setAppName('GT9000.py').setMaster('local[*]')
sc = SparkContext(conf=conf)

# 天猫及京东的销量数据
originTMRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\tianmao.txt')
originJDRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\jd.txt')

mapTMRDD = originTMRDD.map(lambda row: (str(row).split('\t')[0], int(str(row).split('\t')[2])))
mapJDRDD = originJDRDD.map(lambda row: (str(row).split('\t')[0], int(str(row).split('\t')[2])))

# 整合天猫及京东的销量数据并取均值
resultRDD = mapTMRDD.union(mapJDRDD).reduceByKey(lambda a, b: (a + b) / 2)

# print(resultRDD.collect())

# 商品信息数据
originGoodsRDD = sc.textFile('D:\\Software\\Workspace\\PycharmProjects\\川大\\SparkTest01\\goods.txt')
mapGoodsRDD = originGoodsRDD.map(lambda row: (str(row).split('\t')[0], str(row).split('\t')[1]))

# 将商品信息数据及销量数据关联
joinRDD = mapGoodsRDD.join(resultRDD)
list = joinRDD.sortBy(lambda tuple: tuple[0]).map(lambda tuple: tuple[1]).collect()

for t in list:
    print('商品：', t[0], ', 销量：', t[1])
