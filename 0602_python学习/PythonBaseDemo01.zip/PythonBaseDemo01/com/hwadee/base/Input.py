# 相当于 Java 中的 Scanner(System.in)
print('请输入姓名：')
name = input()

print('输入的name是：', name)
