names = ['Michael', 'Bob', 'Tracy']

for name in names:
    print(name, ' 在 names 中的位置：', names.index(name))

path = 'D:/Software/Workspace/PycharmProjects/川大/PythonBaseDemo01/com/hwadee/base/For.py'
for str in path:
    print(str, ' 在 names 中的位置：', path.index(str))
