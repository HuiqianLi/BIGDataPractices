# -*- coding: utf-8 -*-

# 等同于 Java 中的 System.out.println
print('Hello World !')
print('Hello World !')
print('Hello', 'World', '!')  # 将多个单词，以空格连接，输出
print('Hello', 'World', '!', sep='-')
print('Hello', 'World', '!', sep='-', end='/')
print('Hello', 'World', '!', sep='-')
