grades = {
    'Michael': 95,
    'Bob': 75,
    'Tracy': 85
}

print('grades:', grades)
print('Michael:', grades['Michael'])

grades['Tom'] = 60
grades['Jerry'] = 99

print('grades:', grades)

print(grades.get('Tome', '该属性不存在'))

grades.pop('Tom')
print('grades:', grades)
