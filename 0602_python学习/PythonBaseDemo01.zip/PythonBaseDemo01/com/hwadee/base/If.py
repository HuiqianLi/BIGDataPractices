age = 100

if age < 0:
    print('年龄异常')
elif age <= 18:
    print('未成年')
elif age <= 40:
    print('壮年')
elif age <= 60:
    print('中年')
else:
    print('老年')
