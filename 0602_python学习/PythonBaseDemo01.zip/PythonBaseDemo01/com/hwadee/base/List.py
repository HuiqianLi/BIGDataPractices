# 直观的看，类似Java中的Array
classmates = ['Michael', 'Bob', 'Tracy']

print('classmates:', len(classmates))
# len:取对象的长度
# print('str:', len('awfj'))

# list 取值；索引 从0开始
print('[0]:', classmates[0])
print('[len(classmates) - 1]:', classmates[len(classmates) - 1])
print('[-1]:', classmates[-1])

classmates.append('Tom')
classmates.insert(0, 'Jerry')

print('classmates:', classmates)
