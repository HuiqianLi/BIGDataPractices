print(abs(100.1))
# print(abs(100.1, 1))
print(max(100, 200))

print(int('123'))
print(int(12.64))
