import math


# 基本函数:包含必要参数
def power(x):
    return math.pow(x, 2)


# 包含：必要参数、默认参数
def power(x, y=2):
    return math.pow(x, y)


# 可变参数；求传入数据的平方和
def powers(*args):
    if len(args) == 0:
        return 0
    else:
        sum = 0
        for x in args:
            sum += math.pow(x, 2)

        return sum


def instance(name, **kwargs):
    person = {'name': name}

    if len(kwargs) > 0:
        for key in kwargs.keys():
            person[key] = kwargs.get(key)

    return person


print(instance('zhangsan', age=18, gender='male'))
