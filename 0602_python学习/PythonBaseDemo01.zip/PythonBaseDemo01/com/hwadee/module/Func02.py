def method01(x):
    if x >= 0:
        return x
    else:
        return -x


def method02(x):
    pass
    # TODO


class Student(object):

    def get(self, attr):
        pass
