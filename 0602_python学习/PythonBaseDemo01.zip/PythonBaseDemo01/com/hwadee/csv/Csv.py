# csv 文件读写操作
import csv

file = open('D:\Software\Workspace\PycharmProjects\川大\PythonBaseDemo01\jobs.csv', mode='a+', encoding='utf-8',
            newline='')

# 当做最基本的文件进行处理
for line in file.readlines():
    print(line)

# 将 file 声明、绑定为csv文件对象 write
write = csv.writer(file)
# 可以通过 csv 文件对象进行读写操作
write.writerow(
    str(
        'title,job_company,salary,address,experience,education,job_count,publish_date,category,keyword,job_desc,company_desc,job_url')
        .split(',')
)

file.close()
