import pandas

# 这是一些显示设置，让数据显示更友好
pandas.set_option('display.max_columns', None)
pandas.set_option('max_colwidth', 30)
pandas.set_option('display.width', 1000)
pandas.set_option('display.unicode.ambiguous_as_wide', True)
pandas.set_option('display.unicode.east_asian_width', True)

pd = pandas.read_csv('D:\Software\Workspace\PycharmProjects\川大\PythonBaseDemo01\jobs.csv', delimiter=',', names=str(
    'title,job_company,salary,address,experience,education,job_count,publish_date,category,keyword,job_desc,company_desc,job_url')
                     .split(',')
                     , encoding='utf-8')

print(pd[100: 200]['title'])
print(pd.iloc[101]['title'])
